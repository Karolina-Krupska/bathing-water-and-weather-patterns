#!/usr/bin/env python3
"""
Step 2: Fit a daily Markov transition model for 4 WP families (overall + optional month-specific),
and validate that it reproduces observed run-lengths and switching rates.

Inputs:
- classifications CSV with at least: year, month, day, regime (1..30)

Outputs:
- Transition matrices (counts + probabilities), overall and (optionally) per month
- Validation summary comparing observed vs simulated:
    * overall switching rate
    * group-specific persistence (Pii) and switching-out rate (1-Pii)
    * run-length summary per group (mean, median, p90, p95, max)
- One summary figure: heatmap + observed vs simulated bars

Run (defaults to May–Sep 2012–2024):
    python step2_markov_4groups_validate.py --base-dir "C:\path\to\folder"

Override period/months:
    python step2_markov_4groups_validate.py --base-dir "..." --start-year 2012 --end-year 2023 --months 5,6,7,8,9

Use month-specific transition matrices:
    python step2_markov_4groups_validate.py --base-dir "..." --monthly

Notes:
- Transitions are computed only within continuous daily segments (gap >1 day breaks a segment).
- Simulations mirror the observed calendar (same dates/months), using empirical distribution of
  season-start states (first day of each season segment).
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# -------------------------
# USER CONFIG (edit these)
# -------------------------
DEFAULT_START_YEAR = 2012
DEFAULT_END_YEAR   = 2024
DEFAULT_MONTHS     = [5, 6, 7, 8, 9]   # May–Sep
DEFAULT_FIT_MONTHLY = True            # set False to skip month-specific matrices


REGIME_TO_GROUP_4 = {
    1: "Cyclonic Atlantic (frontal)",
    2: "Showery maritime / unsettled",
    3: "Convective extremes",
    4: "Showery maritime / unsettled",
    5: "Cyclonic Atlantic (frontal)",
    6: "Convective extremes",
    7: "Cyclonic Atlantic (frontal)",
    8: "Cyclonic Atlantic (frontal)",
    9: "Convective extremes",
    10: "Convective extremes",
    11: "Cyclonic Atlantic (frontal)",
    12: "Convective extremes",
    13: "Settled anticyclonic quiet",
    14: "Showery maritime / unsettled",
    15: "Showery maritime / unsettled",
    16: "Convective extremes",
    17: "Convective extremes",
    18: "Convective extremes",
    19: "Cyclonic Atlantic (frontal)",
    20: "Showery maritime / unsettled",
    21: "Cyclonic Atlantic (frontal)",
    22: "Cyclonic Atlantic (frontal)",
    23: "Settled anticyclonic quiet",
    24: "Cyclonic Atlantic (frontal)",
    25: "Settled anticyclonic quiet",
    26: "Showery maritime / unsettled",
    27: "Convective extremes",
    28: "Cyclonic Atlantic (frontal)",
    29: "Cyclonic Atlantic (frontal)",
    30: "Cyclonic Atlantic (frontal)",
}

GROUP_ORDER = [
    "Cyclonic Atlantic (frontal)",
    "Showery maritime / unsettled",
    "Convective extremes",
    "Settled anticyclonic quiet",
]


def parse_months(s: str) -> List[int]:
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def ensure_columns(df: pd.DataFrame) -> pd.DataFrame:
    needed = {"year", "month", "day", "regime"}
    missing = needed - set(df.columns.str.lower())
    # allow mixed-case columns
    if missing:
        # try to map columns by lower-case
        colmap = {c.lower(): c for c in df.columns}
        if not needed.issubset(colmap.keys()):
            raise ValueError(f"CSV must include columns {sorted(needed)}; got {list(df.columns)}")
        df = df.rename(columns={colmap["year"]: "year", colmap["month"]: "month",
                                colmap["day"]: "day", colmap["regime"]: "regime"})
    else:
        df = df.rename(columns={c: c.lower() for c in df.columns})
    return df[["year", "month", "day", "regime"]].copy()


def add_date_and_group(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["date"] = pd.to_datetime(dict(year=df["year"], month=df["month"], day=df["day"]), errors="coerce")
    if df["date"].isna().any():
        bad = df[df["date"].isna()].head(5)
        raise ValueError(f"Found invalid dates; example rows:\n{bad}")

    # map regime -> group
    df["group"] = df["regime"].map(REGIME_TO_GROUP_4)
    if df["group"].isna().any():
        missing_regs = sorted(df.loc[df["group"].isna(), "regime"].unique().tolist())
        raise ValueError(f"Unmapped regimes found: {missing_regs}. Update REGIME_TO_GROUP_4.")
    df["group"] = pd.Categorical(df["group"], categories=GROUP_ORDER, ordered=True)
    return df


def split_continuous_segments(df: pd.DataFrame) -> List[pd.DataFrame]:
    """
    Split into continuous daily segments based on date gaps > 1 day.
    """
    df = df.sort_values("date").reset_index(drop=True)
    gaps = df["date"].diff().dt.days.fillna(1)
    seg_id = (gaps != 1).cumsum()
    segments = [g.reset_index(drop=True) for _, g in df.groupby(seg_id)]
    return segments


def transition_counts(groups: List[str], order: List[str]) -> np.ndarray:
    idx = {g: i for i, g in enumerate(order)}
    n = len(order)
    counts = np.zeros((n, n), dtype=int)
    for a, b in zip(groups[:-1], groups[1:]):
        counts[idx[a], idx[b]] += 1
    return counts


def counts_to_probs(counts: np.ndarray, eps: float = 0.0) -> np.ndarray:
    """
    Row-normalize counts into probabilities. Optional Laplace smoothing via eps.
    """
    c = counts.astype(float) + eps
    row_sums = c.sum(axis=1, keepdims=True)
    with np.errstate(divide="ignore", invalid="ignore"):
        p = np.divide(c, row_sums, out=np.zeros_like(c), where=row_sums != 0)
    return p


def run_lengths(groups: List[str]) -> Dict[str, List[int]]:
    out: Dict[str, List[int]] = {g: [] for g in GROUP_ORDER}
    if not groups:
        return out
    current = groups[0]
    length = 1
    for g in groups[1:]:
        if g == current:
            length += 1
        else:
            out[current].append(length)
            current = g
            length = 1
    out[current].append(length)
    return out


def summarize_run_lengths(rl: Dict[str, List[int]]) -> pd.DataFrame:
    rows = []
    for g in GROUP_ORDER:
        vals = np.array(rl[g], dtype=float)
        if vals.size == 0:
            rows.append(dict(group=g, n_runs=0, mean=np.nan, median=np.nan, p90=np.nan, p95=np.nan, max=np.nan))
        else:
            rows.append(dict(
                group=g,
                n_runs=int(vals.size),
                mean=float(vals.mean()),
                median=float(np.median(vals)),
                p90=float(np.quantile(vals, 0.90)),
                p95=float(np.quantile(vals, 0.95)),
                max=float(vals.max()),
            ))
    return pd.DataFrame(rows)


def switching_rate(groups: List[str]) -> float:
    if len(groups) < 2:
        return np.nan
    changes = sum(a != b for a, b in zip(groups[:-1], groups[1:]))
    return changes / (len(groups) - 1)


@dataclass
class MarkovFit:
    P_overall: np.ndarray
    C_overall: np.ndarray
    P_by_month: Dict[int, np.ndarray]
    C_by_month: Dict[int, np.ndarray]
    start_dist: np.ndarray  # distribution over GROUP_ORDER for season starts


def fit_markov(df: pd.DataFrame, monthly: bool, eps: float = 0.0) -> MarkovFit:
    # continuous segments
    segs = split_continuous_segments(df)

    # overall transitions from all segments
    C = np.zeros((len(GROUP_ORDER), len(GROUP_ORDER)), dtype=int)
    starts = []
    for seg in segs:
        g = seg["group"].astype(str).tolist()
        C += transition_counts(g, GROUP_ORDER)
        if len(g) > 0:
            starts.append(g[0])

    start_counts = np.array([starts.count(g) for g in GROUP_ORDER], dtype=float)
    start_dist = start_counts / start_counts.sum() if start_counts.sum() else np.ones(len(GROUP_ORDER)) / len(GROUP_ORDER)

    P = counts_to_probs(C, eps=eps)

    Pm: Dict[int, np.ndarray] = {}
    Cm: Dict[int, np.ndarray] = {}
    if monthly:
        for m, gdf in df.groupby(df["date"].dt.month):
            # compute within-month transitions (still respecting day continuity within that month)
            segs_m = split_continuous_segments(gdf)
            C_m = np.zeros_like(C)
            for seg in segs_m:
                gg = seg["group"].astype(str).tolist()
                C_m += transition_counts(gg, GROUP_ORDER)
            Cm[int(m)] = C_m
            Pm[int(m)] = counts_to_probs(C_m, eps=eps)

    return MarkovFit(P_overall=P, C_overall=C, P_by_month=Pm, C_by_month=Cm, start_dist=start_dist)


def simulate_sequence(dates: pd.DatetimeIndex, fit: MarkovFit, monthly: bool, rng: np.random.Generator) -> List[str]:
    """
    Simulate groups for the given daily dates. Uses empirical season-start distribution.
    Uses month-specific matrices if monthly=True and matrix exists; otherwise falls back to overall.
    """
    n = len(dates)
    if n == 0:
        return []
    states = []
    # start
    s0 = rng.choice(GROUP_ORDER, p=fit.start_dist)
    states.append(s0)

    idx = {g: i for i, g in enumerate(GROUP_ORDER)}
    for t in range(1, n):
        prev = states[-1]
        m = int(dates[t].month)
        P = fit.P_by_month.get(m, fit.P_overall) if monthly else fit.P_overall
        p = P[idx[prev], :]
        # handle potential zero row (if no data for that previous state): fall back to overall
        if p.sum() <= 0:
            p = fit.P_overall[idx[prev], :]
        nxt = rng.choice(GROUP_ORDER, p=p)
        states.append(nxt)
    return states


def build_calendar(df: pd.DataFrame) -> List[pd.DatetimeIndex]:
    """
    Return list of date sequences (continuous segments) to simulate, matching observed segments.
    """
    segs = split_continuous_segments(df)
    calendars = [pd.DatetimeIndex(seg["date"].tolist()) for seg in segs]
    return calendars


def validate(df: pd.DataFrame, fit: MarkovFit, monthly: bool, n_sims: int, seed: int) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Returns:
      - validation_summary (wide table: observed vs simulated)
      - run_length_detail (per group, observed vs simulated summary stats)
    """
    # observed metrics per segment then aggregated
    calendars = build_calendar(df)
    # observed run lengths and switching from each segment
    obs_rl = {g: [] for g in GROUP_ORDER}
    obs_switches = []
    for seg in split_continuous_segments(df):
        gg = seg["group"].astype(str).tolist()
        rl_seg = run_lengths(gg)
        for g in GROUP_ORDER:
            obs_rl[g].extend(rl_seg[g])
        obs_switches.append(switching_rate(gg))
    obs_switch = float(np.nanmean(obs_switches)) if obs_switches else np.nan
    obs_rl_sum = summarize_run_lengths(obs_rl).set_index("group")

    # simulate
    rng = np.random.default_rng(seed)
    sim_switches = []
    sim_rl_all = {g: [] for g in GROUP_ORDER}
    for _ in range(n_sims):
        for cal in calendars:
            sim = simulate_sequence(cal, fit, monthly, rng)
            rl = run_lengths(sim)
            for g in GROUP_ORDER:
                sim_rl_all[g].extend(rl[g])
            sim_switches.append(switching_rate(sim))
    sim_switch = float(np.nanmean(sim_switches)) if sim_switches else np.nan
    sim_rl_sum = summarize_run_lengths(sim_rl_all).set_index("group")

    # switching out rates: 1 - Pii
    obs_P = fit.P_overall  # observed MLE
    out_rate = 1 - np.diag(obs_P)
    pers = np.diag(obs_P)

    summary_rows = []
    summary_rows.append(dict(metric="overall_switching_rate", observed=obs_switch, simulated=sim_switch, delta=sim_switch-obs_switch))
    for i, g in enumerate(GROUP_ORDER):
        summary_rows.append(dict(metric=f"persistence_Pii::{g}", observed=float(pers[i]), simulated=np.nan, delta=np.nan))
        summary_rows.append(dict(metric=f"switch_out_rate_1-Pii::{g}", observed=float(out_rate[i]), simulated=np.nan, delta=np.nan))
    validation_summary = pd.DataFrame(summary_rows)

    # run-length detail table
    rl_detail = obs_rl_sum.join(sim_rl_sum, lsuffix="_obs", rsuffix="_sim")
    # deltas for key stats
    for col in ["mean", "median", "p90", "p95", "max"]:
        rl_detail[f"{col}_delta"] = rl_detail[f"{col}_sim"] - rl_detail[f"{col}_obs"]
    rl_detail = rl_detail.reset_index()

    return validation_summary, rl_detail


def save_matrix(counts: np.ndarray, probs: np.ndarray, out_counts: Path, out_probs: Path) -> None:
    dfc = pd.DataFrame(counts, index=GROUP_ORDER, columns=GROUP_ORDER)
    dfp = pd.DataFrame(probs, index=GROUP_ORDER, columns=GROUP_ORDER)
    dfc.to_csv(out_counts)
    dfp.to_csv(out_probs)


def plot_summary(out_png: Path, fit: MarkovFit, monthly: bool, rl_detail: pd.DataFrame, validation_summary: pd.DataFrame) -> None:
    fig = plt.figure(figsize=(14, 9))
    gs = fig.add_gridspec(2, 2, height_ratios=[1, 1])

    # Heatmap overall P
    ax0 = fig.add_subplot(gs[0, 0])
    P = fit.P_overall
    im = ax0.imshow(P, vmin=0, vmax=max(0.4, P.max()))
    ax0.set_title("Overall transition probabilities (Markov P)")
    ax0.set_xticks(range(len(GROUP_ORDER)))
    ax0.set_yticks(range(len(GROUP_ORDER)))
    ax0.set_xticklabels(GROUP_ORDER, rotation=45, ha="right")
    ax0.set_yticklabels(GROUP_ORDER)
    for i in range(len(GROUP_ORDER)):
        for j in range(len(GROUP_ORDER)):
            ax0.text(j, i, f"{P[i,j]:.2f}", ha="center", va="center", fontsize=9)
    fig.colorbar(im, ax=ax0, fraction=0.046, pad=0.04)

    # Run-length mean (obs vs sim) with p95 dots
    ax1 = fig.add_subplot(gs[0, 1])
    x = np.arange(len(GROUP_ORDER))
    width = 0.35
    rl = rl_detail.set_index("group").loc[GROUP_ORDER]
    ax1.bar(x - width/2, rl["mean_obs"], width, label="Observed mean run length")
    ax1.bar(x + width/2, rl["mean_sim"], width, label="Simulated mean run length")
    ax1.scatter(x - width/2, rl["p95_obs"], marker="o", label="Observed p95", zorder=3)
    ax1.scatter(x + width/2, rl["p95_sim"], marker="o", label="Simulated p95", zorder=3)
    ax1.set_xticks(x)
    ax1.set_xticklabels(GROUP_ORDER, rotation=45, ha="right")
    ax1.set_title("Run-length validation (mean bars, p95 dots)")
    ax1.set_ylabel("Days")
    ax1.legend(fontsize=8)

    # Switching rate
    ax2 = fig.add_subplot(gs[1, 0])
    vs = validation_summary.set_index("metric")
    obs = float(vs.loc["overall_switching_rate", "observed"])
    sim = float(vs.loc["overall_switching_rate", "simulated"])
    ax2.bar([0, 1], [obs, sim])
    ax2.set_xticks([0, 1])
    ax2.set_xticklabels(["Observed", "Simulated"])
    ax2.set_title("Overall switching rate validation")
    ax2.set_ylabel("P(change on next day)")

    # Monthly Pii lines (optional)
    ax3 = fig.add_subplot(gs[1, 1])
    if monthly and fit.P_by_month:
        months = sorted(fit.P_by_month.keys())
        for i, g in enumerate(GROUP_ORDER):
            pii = [fit.P_by_month[m][i, i] if m in fit.P_by_month else np.nan for m in months]
            ax3.plot(months, pii, marker="o", label=g)
        ax3.set_xticks(months)
        ax3.set_title("Month-specific persistence Pii (optional)")
        ax3.set_xlabel("Month")
        ax3.set_ylabel("P(stay in same group)")
        ax3.legend(fontsize=8)
    else:
        ax3.axis("off")
        ax3.text(0.5, 0.5, "Monthly matrices not requested\n(--monthly)", ha="center", va="center")

    fig.tight_layout()
    fig.savefig(out_png, dpi=200)
    plt.close(fig)




def plot_monthly_matrices(out_png: Path, P_by_month: Dict[int, np.ndarray], months: List[int]) -> None:
    """Save a compact figure of month-specific transition matrices (heatmaps)."""
    ms = [m for m in months if m in P_by_month]
    if not ms:
        return
    n = len(ms)
    ncols = min(5, n)
    nrows = (n + ncols - 1) // ncols

    fig, axes = plt.subplots(nrows=nrows, ncols=ncols, figsize=(3.6*ncols, 3.2*nrows), constrained_layout=True)
    if nrows == 1 and ncols == 1:
        axes = np.array([[axes]])
    elif nrows == 1:
        axes = np.array([axes])
    elif ncols == 1:
        axes = np.array([[ax] for ax in axes])

    vmax = 1.0
    for i, m in enumerate(ms):
        r, c = divmod(i, ncols)
        ax = axes[r, c]
        P = P_by_month[m]
        im = ax.imshow(P, vmin=0, vmax=vmax)
        ax.set_title(f"Month {m:02d}")
        ax.set_xticks(range(len(GROUP_ORDER)))
        ax.set_yticks(range(len(GROUP_ORDER)))
        ax.set_xticklabels(GROUP_ORDER, rotation=45, ha="right", fontsize=7)
        ax.set_yticklabels(GROUP_ORDER, fontsize=7)

        for rr in range(P.shape[0]):
            for cc in range(P.shape[1]):
                ax.text(cc, rr, f"{P[rr, cc]:.2f}", ha="center", va="center", fontsize=7)

    # turn off any unused axes
    for j in range(n, nrows*ncols):
        r, c = divmod(j, ncols)
        axes[r, c].axis("off")

    fig.colorbar(im, ax=axes.ravel().tolist(), shrink=0.8)
    fig.savefig(out_png, dpi=200)
    plt.close(fig)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-dir", type=str, default=".", help="Folder containing classifications CSV (and outputs will be created here).")
    ap.add_argument("--classif-csv", type=str, default="classifications_30regimes(21) (4).csv",
                    help="Filename of classifications CSV inside base-dir (or full path).")
    ap.add_argument("--start-year", type=int, default=DEFAULT_START_YEAR)
    ap.add_argument("--end-year", type=int, default=DEFAULT_END_YEAR)
    ap.add_argument("--months", type=str, default=",".join(str(m) for m in DEFAULT_MONTHS))
    ap.add_argument("--monthly", action="store_true", help="Force month-specific matrices on (overrides DEFAULT_FIT_MONTHLY).")
    ap.add_argument("--no-monthly", action="store_true", help="Disable month-specific matrices (overrides DEFAULT_FIT_MONTHLY).")
    ap.add_argument("--eps", type=float, default=0.0, help="Optional Laplace smoothing added to transition counts before normalization.")
    ap.add_argument("--n-sims", type=int, default=500, help="Number of Monte Carlo simulations for validation.")
    ap.add_argument("--seed", type=int, default=123, help="Random seed for simulations.")
    args = ap.parse_args()

    # Decide whether to fit month-specific matrices
    monthly_flag = DEFAULT_FIT_MONTHLY
    if args.monthly:
        monthly_flag = True
    if getattr(args, 'no_monthly', False):
        monthly_flag = False


    base = Path(args.base_dir)
    classif_path = Path(args.classif_csv)
    if not classif_path.is_file():
        classif_path = base / args.classif_csv
    if not classif_path.is_file():
        raise FileNotFoundError(f"Could not find classifications CSV at: {classif_path}")

    months = parse_months(args.months)

    # classifications CSV often starts with commented metadata lines beginning with '#'
    df = pd.read_csv(classif_path, comment='#')
    df = ensure_columns(df)
    # ensure numeric types (handles leading zeros like '01')
    for col in ["year", "month", "day", "regime"]:
        df[col] = pd.to_numeric(df[col], errors="raise").astype(int)
    df = add_date_and_group(df)

    # filter
    df = df[df["year"].between(args.start_year, args.end_year) & df["month"].isin(months)].copy()
    df = df.sort_values("date").reset_index(drop=True)

    # enforce unique dates
    if df["date"].duplicated().any():
        dups = df.loc[df["date"].duplicated(), "date"].dt.strftime("%Y-%m-%d").head(10).tolist()
        raise ValueError(f"Duplicate dates detected after filtering. Example duplicates: {dups}")

    # warn if expected day count doesn't match full seasons (optional)
    # (do not assert, because user might deliberately use partial windows)
    expected_full = 153 * (args.end_year - args.start_year + 1) if set(months) == {5,6,7,8,9} else None
    if expected_full is not None:
        actual = df["date"].nunique()
        if actual != expected_full:
            print(f"[WARN] Unique dates={actual} but expected {expected_full} for full May–Sep seasons. "
                  f"This is OK if you intended partial coverage.")

    outname = f"outputs_step2_markov_{args.start_year}_{args.end_year}_m{'-'.join(map(str, months))}" + ("_monthly" if args.monthly else "")
    outdir = base / outname
    outdir.mkdir(parents=True, exist_ok=True)

    # fit
    fit = fit_markov(df, monthly=monthly_flag, eps=args.eps)

    # save matrices
    save_matrix(fit.C_overall, fit.P_overall, outdir / "transition_counts_overall.csv", outdir / "transition_probs_overall.csv")
    if args.monthly:
        for m in sorted(fit.P_by_month.keys()):
            save_matrix(fit.C_by_month[m], fit.P_by_month[m],
                        outdir / f"transition_counts_month_{m:02d}.csv",
                        outdir / f"transition_probs_month_{m:02d}.csv")

    # validate
    validation_summary, rl_detail = validate(df, fit, monthly=monthly_flag, n_sims=args.n_sims, seed=args.seed)
    validation_summary.to_csv(outdir / "validation_summary.csv", index=False)
    rl_detail.to_csv(outdir / "run_length_validation.csv", index=False)

    # figure
    plot_summary(outdir / "step2_markov_validation.png", fit, monthly=monthly_flag, rl_detail=rl_detail, validation_summary=validation_summary)

    # monthly heatmaps (if enabled)
    if monthly_flag and fit.P_by_month:
        plot_monthly_matrices(outdir / "monthly_transition_matrices.png", fit.P_by_month, months)

    print(
        f"Done.\nOutputs written to: {outdir}\n"
        f"- transition_probs_overall.csv\n"
        f"- run_length_validation.csv\n"
        f"- validation_summary.csv\n"
        f"- step2_markov_validation.png\n"
        + (f"- monthly_transition_matrices.png\n"
           f"- transition_probs_month_XX.csv (one per month present)\n" if monthly_flag else "")
    )



if __name__ == "__main__":
    main()
