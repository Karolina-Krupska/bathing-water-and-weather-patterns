"""Step 1 — Switch everything to 4 families and re-run baseline summaries (counts, run-lengths, transitions)
PLUS: save a single summary figure.

What it produces in OUT_DIR:
- group_counts_fractions.csv
- transition_counts.csv
- transition_probs.csv
- run_length_summary.csv
- step1_summary_figure.png

Optional (if rainfall workbooks exist in BASE_DIR):
- SWEW_MaySep_rainfall_by_group.csv
- Adds rainfall panel to the summary figure.

How to change the analysis period:
- Edit START_YEAR / END_YEAR / MONTHS below, OR run with CLI args:
  python step1_baseline_4groups_with_figure.py --start-year 2012 --end-year 2024 --months 5,6,7,8,9
"""
from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# =========================
# PATHS (EDIT THESE)
# =========================
BASE_DIR = Path(r"C:\Users\earth\OneDrive - University of Reading\Python codes objective 2\Beyond_rainfall_triggers\ascendant conditions")

CLASSIFICATIONS_CSV = BASE_DIR / "classifications_30regimes(21) (4).csv"

# Rainfall summary workbooks (optional)
FULLRANGE_STATS_XLSX = BASE_DIR / "fullrange_noqc_stats.xlsx"
MAYSEP_SWEW_STATS_XLSX = BASE_DIR / "SWEW_MaySep_by_regime_NOQC_stats.xlsx"


# =========================
# 30 regimes -> 4 groups
# (REGIME_TO_GROUP_4 embedded directly)
# =========================
REGIME_TO_GROUP_4 = {
    1: "Cyclonic Atlantic (frontal)",
    2: "Showery maritime / unsettled",
    3: "Convective extremes",
    4: "Showery maritime / unsettled",
    5: "Cyclonic Atlantic (frontal)",
    6: "Convective extremes",
    7: "Cyclonic Atlantic (frontal)",
    8: "Cyclonic Atlantic (frontal)",
    9: "Convective extremes",
    10: "Convective extremes",
    11: "Cyclonic Atlantic (frontal)",
    12: "Convective extremes",
    13: "Settled anticyclonic quiet",
    14: "Showery maritime / unsettled",
    15: "Showery maritime / unsettled",
    16: "Convective extremes",
    17: "Convective extremes",
    18: "Convective extremes",
    19: "Cyclonic Atlantic (frontal)",
    20: "Showery maritime / unsettled",
    21: "Cyclonic Atlantic (frontal)",
    22: "Cyclonic Atlantic (frontal)",
    23: "Settled anticyclonic quiet",
    24: "Cyclonic Atlantic (frontal)",
    25: "Settled anticyclonic quiet",
    26: "Showery maritime / unsettled",
    27: "Convective extremes",
    28: "Cyclonic Atlantic (frontal)",
    29: "Cyclonic Atlantic (frontal)",
    30: "Cyclonic Atlantic (frontal)",
}

GROUP_ORDER = [
    "Cyclonic Atlantic (frontal)",
    "Showery maritime / unsettled",
    "Convective extremes",
    "Settled anticyclonic quiet",
]

# =========================
# Default analysis settings
# (override via CLI if you want)
# =========================
START_YEAR = 2012
END_YEAR = 2024
MONTHS = [5, 6, 7, 8, 9]  # May–Sep


# =========================
# Helpers
# =========================
def expected_days(start_year: int, end_year: int, months: list[int]) -> int:
    """Calendar-accurate expected day count for the given years and month set."""
    expected = 0
    for y in range(start_year, end_year + 1):
        for m in months:
            expected += pd.Period(f"{y}-{m:02d}").days_in_month
    return expected


def run_lengths(groups: list[str], dates: list[pd.Timestamp]) -> pd.DataFrame:
    """Run lengths for consecutive equal groups; breaks if date gap != 1 day."""
    out: list[tuple[str, int]] = []
    start = 0
    for i in range(1, len(groups)):
        if groups[i] != groups[i - 1] or (dates[i] != dates[i - 1] + pd.Timedelta(days=1)):
            out.append((groups[i - 1], i - start))
            start = i
    if groups:
        out.append((groups[-1], len(groups) - start))
    return pd.DataFrame(out, columns=["group", "run_length"])


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--start-year", type=int, default=START_YEAR)
    p.add_argument("--end-year", type=int, default=END_YEAR)
    p.add_argument(
        "--months",
        type=str,
        default=",".join(map(str, MONTHS)),
        help="Comma-separated months, e.g. 5,6,7,8,9",
    )
    p.add_argument(
        "--outdir",
        type=str,
        default="",
        help="Optional output directory. If blank, uses BASE_DIR/outputs_step1_4groups_<period>",
    )
    p.add_argument(
        "--no-rainfall",
        action="store_true",
        help="Skip rainfall workbook checks/summary even if files exist.",
    )
    return p.parse_args()


def main() -> None:
    args = parse_args()
    start_year = args.start_year
    end_year = args.end_year
    months = [int(x.strip()) for x in args.months.split(",") if x.strip()]
    months = sorted(set(months))

    if start_year > end_year:
        raise ValueError("start-year must be <= end-year")
    if any(m < 1 or m > 12 for m in months):
        raise ValueError(f"Invalid months: {months}")

    # Output directory (include period in name to avoid accidental overwrites)
    if args.outdir:
        out_dir = Path(args.outdir)
    else:
        out_dir = BASE_DIR / f"outputs_step1_4groups_{start_year}_{end_year}_m{'-'.join(map(str, months))}"
    out_dir.mkdir(parents=True, exist_ok=True)

    # -------------------------
    # Load classifications
    # -------------------------
    df = pd.read_csv(CLASSIFICATIONS_CSV, comment="#")
    df["date"] = pd.to_datetime(dict(year=df["year"], month=df["month"], day=df["day"]))
    df["group"] = df["regime"].map(REGIME_TO_GROUP_4)

    if df["group"].isna().any():
        missing = sorted(df.loc[df["group"].isna(), "regime"].unique().tolist())
        raise ValueError(f"Some regimes did not map to a group: {missing}")

    season = df[(df["year"].between(start_year, end_year)) & (df["month"].isin(months))].copy()
    season = season.sort_values("date")

    # Sanity check: expected day count
    expected = expected_days(start_year, end_year, months)
    actual = int(season["date"].nunique())
    years_present = sorted(season["year"].unique().tolist())
    months_present = sorted(season["month"].unique().tolist())
    print("\n=== Period check ===")
    print(f"Years present: {years_present}")
    print(f"Months present: {months_present}")
    print(f"Unique dates: {actual} | Expected (calendar): {expected}")
    if actual != expected:
        # Don't hard-crash (sometimes you may have missing dates), but do make it loud.
        print("WARNING: date count mismatch. Check missing/duplicate dates before interpreting run-lengths/transitions.")

    # -------------------------
    # 1) Counts / fractions
    # -------------------------
    counts = season["group"].value_counts().reindex(GROUP_ORDER).fillna(0).astype(int)
    counts = counts.rename("days").to_frame()
    counts["fraction"] = counts["days"] / counts["days"].sum() if counts["days"].sum() > 0 else np.nan
    counts.to_csv(out_dir / "group_counts_fractions.csv")
    print("\n=== Group counts ===")
    print(counts)

    # -------------------------
    # 2) Transition matrix (day-to-day)
    #    (ignore gaps between Sep->May etc.)
    # -------------------------
    season["next_date"] = season["date"].shift(-1)
    season["next_group"] = season["group"].shift(-1)
    is_next_day = season["next_date"] == (season["date"] + pd.Timedelta(days=1))
    trans = season[is_next_day].copy()

    mat_counts = (
        pd.crosstab(trans["group"], trans["next_group"])
        .reindex(index=GROUP_ORDER, columns=GROUP_ORDER)
        .fillna(0)
        .astype(int)
    )
    mat_probs = mat_counts.div(mat_counts.sum(axis=1).replace(0, np.nan), axis=0)

    mat_counts.to_csv(out_dir / "transition_counts.csv")
    mat_probs.to_csv(out_dir / "transition_probs.csv")

    print("\n=== Transition probabilities (row=from, col=to) ===")
    print(mat_probs.round(3))

    # -------------------------
    # 3) Run-length stats by group
    # -------------------------
    rl = run_lengths(season["group"].tolist(), season["date"].tolist())
    rl_summary = (
        rl.groupby("group")["run_length"]
        .agg(
            n_runs="count",
            mean="mean",
            median="median",
            max="max",
            p90=lambda s: float(np.quantile(s, 0.90)),
            p95=lambda s: float(np.quantile(s, 0.95)),
        )
        .reindex(GROUP_ORDER)
    )

    rl_summary.to_csv(out_dir / "run_length_summary.csv")
    print("\n=== Run-length summary ===")
    print(rl_summary.round(2))

    # -------------------------
    # OPTIONAL: Rainfall workbook checks + summary by group
    # -------------------------
    fam_rain = None
    if (not args.no_rainfall) and FULLRANGE_STATS_XLSX.exists() and MAYSEP_SWEW_STATS_XLSX.exists():
        try:
            full = pd.read_excel(FULLRANGE_STATS_XLSX, sheet_name="daily_metrics")
            maysep = pd.read_excel(MAYSEP_SWEW_STATS_XLSX, sheet_name="daily_metrics")
            full["date"] = pd.to_datetime(full["date"])
            maysep["date"] = pd.to_datetime(maysep["date"])

            # Compare: fullrange filtered to SWEW and chosen months
            full_swew = full[(full["region"] == "SWEW") & (full["date"].dt.month.isin(months))].copy()

            def summarize(d: pd.DataFrame) -> pd.DataFrame:
                g = d.groupby("regime")["daily_depth_mm"]
                return pd.DataFrame(
                    {
                        "n_days": g.size(),
                        "mean_mm": g.mean(),
                        "median_mm": g.median(),
                        "p90_mm": g.quantile(0.9),
                        "p95_mm": g.quantile(0.95),
                    }
                ).sort_index()

            s_full = summarize(full_swew)
            s_maysep = summarize(maysep)
            max_abs_diff = (s_full - s_maysep).abs().max()

            print("\n=== Rainfall workbook check (SWEW, chosen months): max abs diff ===")
            print(max_abs_diff)

            maysep["group"] = maysep["regime"].map(REGIME_TO_GROUP_4)
            fam_rain = (
                maysep.groupby("group")
                .agg(
                    n_days=("daily_depth_mm", "size"),
                    mean_mm=("daily_depth_mm", "mean"),
                    median_mm=("daily_depth_mm", "median"),
                    p90_mm=("daily_depth_mm", lambda s: float(np.quantile(s, 0.90))),
                    p95_mm=("daily_depth_mm", lambda s: float(np.quantile(s, 0.95))),
                    mean_wet_fraction=("wet_fraction", "mean"),
                )
                .reindex(GROUP_ORDER)
            )
            fam_rain.to_csv(out_dir / "SWEW_rainfall_by_group.csv")
            print("\n=== SWEW rainfall summary by group (daily_depth_mm) ===")
            print(fam_rain.round(3))
        except Exception as e:
            print(f"WARNING: rainfall workbook processing failed: {e}")

    # -------------------------
    # 4) One summary figure (single PNG)
    # -------------------------
    fig, axes = plt.subplots(2, 2, figsize=(13, 8), constrained_layout=True)
    ax_counts, ax_runs, ax_trans, ax_rain = axes.ravel()

    # Panel A: counts
    ax_counts.bar(range(len(GROUP_ORDER)), counts["days"].values)
    ax_counts.set_xticks(range(len(GROUP_ORDER)))
    ax_counts.set_xticklabels(GROUP_ORDER, rotation=20, ha="right")
    ax_counts.set_title("A) Days by group")
    ax_counts.set_ylabel("Days")

    # Panel B: run-length (mean + p95)
    x = np.arange(len(GROUP_ORDER))
    mean_rl = rl_summary["mean"].values
    p95_rl = rl_summary["p95"].values
    ax_runs.bar(x, mean_rl)
    ax_runs.plot(x, p95_rl, marker="o", linestyle="None")
    ax_runs.set_xticks(x)
    ax_runs.set_xticklabels(GROUP_ORDER, rotation=20, ha="right")
    ax_runs.set_title("B) Run length (mean bars, p95 dots)")
    ax_runs.set_ylabel("Days")

    # Panel C: transition matrix heatmap
    im = ax_trans.imshow(mat_probs.values.astype(float), aspect="auto")
    ax_trans.set_xticks(range(len(GROUP_ORDER)))
    ax_trans.set_yticks(range(len(GROUP_ORDER)))
    ax_trans.set_xticklabels(GROUP_ORDER, rotation=20, ha="right")
    ax_trans.set_yticklabels(GROUP_ORDER)
    ax_trans.set_title("C) Transition probabilities (next-day)")
    fig.colorbar(im, ax=ax_trans, fraction=0.046, pad=0.04)

    # annotate transition probs
    for i in range(len(GROUP_ORDER)):
        for j in range(len(GROUP_ORDER)):
            val = mat_probs.iloc[i, j]
            if np.isfinite(val):
                ax_trans.text(j, i, f"{val:.2f}", ha="center", va="center", fontsize=8)

    # Panel D: rainfall (optional)
    if fam_rain is not None and "mean_mm" in fam_rain.columns:
        ax_rain.bar(x, fam_rain["mean_mm"].values)
        ax_rain.plot(x, fam_rain["p95_mm"].values, marker="o", linestyle="None")
        ax_rain.set_xticks(x)
        ax_rain.set_xticklabels(GROUP_ORDER, rotation=20, ha="right")
        ax_rain.set_title("D) SWEW rainfall (mean bars, p95 dots)")
        ax_rain.set_ylabel("mm/day")
    else:
        ax_rain.axis("off")
        ax_rain.text(
            0.5,
            0.5,
            "D) Rainfall panel skipped\n(rainfall workbooks not found\nor --no-rainfall used)",
            ha="center",
            va="center",
        )

    # Global title
    month_str = ",".join(map(str, months))
    fig.suptitle(f"Step 1 summary | Years {start_year}–{end_year} | Months {month_str}", fontsize=12)

    out_png = out_dir / "step1_summary_figure.png"
    fig.savefig(out_png, dpi=200)
    plt.close(fig)

    print(f"\nSaved summary figure: {out_png}")
    print(f"Outputs written to: {out_dir}")


if __name__ == "__main__":
    main()
