#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Step 3: Arnell-style storylines by perturbing a Markov transition model (4 groups)

What this does
--------------
1) Reads daily 30-regime classifications (1..30)
2) Maps to 4 families (REGIME_TO_GROUP_4)
3) Fits baseline 4x4 Markov transition matrix:
   - overall (single matrix) OR
   - monthly (one matrix per month)
4) Creates "storylines" by perturbing persistence / key transitions (stress tests)
5) Simulates many Apr–Sep seasons under:
   - baseline Markov
   - each storyline
6) Produces paper-ready figures + CSV outputs.

Usage (examples)
----------------
# Default: 2012–2024, Apr–Sep, monthly matrices ON, 5000 simulations
python step3_storylines_markov_4groups.py --base-dir "C:\\...\\ascendant conditions"

# Change dates / months
python step3_storylines_markov_4groups.py --base-dir "C:\\...\\ascendant conditions" --start-year 2014 --end-year 2023 --months 6,7,8

# Turn off monthly matrices (use single overall matrix)
python step3_storylines_markov_4groups.py --base-dir "C:\\...\\ascendant conditions" --no-monthly

Outputs go to: outputs_step3_storylines_<years>_<months>/
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
import os
import datetime
import re
from typing import Dict, List, Tuple, Optional

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# -----------------------------
# Defaults (edit here if desired)
# -----------------------------
DEFAULT_START_YEAR = 2012
DEFAULT_END_YEAR = 2024
DEFAULT_MONTHS = [4, 5, 6, 7, 8, 9]
DEFAULT_BASE_DIR = Path(r"C:\\Users\\earth\\OneDrive - University of Reading\\Python codes objective 2\\Beyond_rainfall_triggers\\ascendant conditions")
DEFAULT_USE_MONTHLY = True

DEFAULT_N_SIMS = 5000
DEFAULT_RANDOM_SEED = 42

# Storyline perturbation defaults (tune as needed)
DEFAULT_DELTA_PERSIST = 0.10         # boost P(stay) for target groups
DEFAULT_DELTA_BURST = 0.12           # boost P(settled -> convective)
DEFAULT_DELTA_RETURN = 0.12          # boost P(convective -> settled)
DEFAULT_FLIP_DAY = 91               # around mid-season for Apr-Sep (183-day season)
# Optional rainfall attachment (for flip timing and anchor-year plausibility plots)
# NOTE: These are *inputs only*; Step 3 remains a synoptic-family sequence generator.
DEFAULT_ATTACH_RAINFALL = True
DEFAULT_RAIN_DIR = r"C:\Users\earth\OneDrive - University of Reading\Regime data QC - log mean - no QC - raw data - Copy"
DEFAULT_RAIN_SUMMARY_XLSX = r"C:\Users\earth\OneDrive - University of Reading\Python codes objective 2\Beyond_rainfall_triggers\ascendant conditions\Daily rainfall metrix.xlsx"
DEFAULT_HEAVY_RAIN_Q = 0.95  # quantile threshold for "heavy-rain day" counts (computed from observed selected-month rainfall)


# -----------------------------
# 30-regime -> 4-group mapping
# -----------------------------
REGIME_TO_GROUP_4: Dict[int, str] = {
    1: "Cyclonic Atlantic (frontal)",
    2: "Showery maritime / unsettled",
    3: "Convective extremes",
    4: "Showery maritime / unsettled",
    5: "Cyclonic Atlantic (frontal)",
    6: "Convective extremes",
    7: "Cyclonic Atlantic (frontal)",
    8: "Cyclonic Atlantic (frontal)",
    9: "Convective extremes",
    10: "Convective extremes",
    11: "Cyclonic Atlantic (frontal)",
    12: "Convective extremes",
    13: "Settled anticyclonic quiet",
    14: "Showery maritime / unsettled",
    15: "Showery maritime / unsettled",
    16: "Convective extremes",
    17: "Convective extremes",
    18: "Convective extremes",
    19: "Cyclonic Atlantic (frontal)",
    20: "Showery maritime / unsettled",
    21: "Cyclonic Atlantic (frontal)",
    22: "Cyclonic Atlantic (frontal)",
    23: "Settled anticyclonic quiet",
    24: "Cyclonic Atlantic (frontal)",
    25: "Settled anticyclonic quiet",
    26: "Showery maritime / unsettled",
    27: "Convective extremes",
    28: "Cyclonic Atlantic (frontal)",
    29: "Cyclonic Atlantic (frontal)",
    30: "Cyclonic Atlantic (frontal)",
}

GROUP_ORDER = [
    "Cyclonic Atlantic (frontal)",
    "Showery maritime / unsettled",
    "Convective extremes",
    "Settled anticyclonic quiet",
]

# Indices of 'wet/unsettled' families for flip diagnostics (Cyclonic + Showery)
WET_STATE_IDX = [0, 1, 2]  # Cyclonic + Showery + Convective (all non-Settled)


# -----------------------------
# Storyline labels (for figures / tables)
# -----------------------------
STORYLINE_LABELS: Dict[str, str] = {
    "baseline": "Observed transition",
    "persistent_wet": "Persistent wet",
    "persistent_dry": "Persistent dry",
    "dry_with_bursts": "Dry with storm outbreaks",
    "flip_wet_to_dry": "Wet → Dry",
    "flip_dry_to_wet": "Dry → Wet",
}

STORYLINE_ORDER: List[str] = [
    "baseline",
    "persistent_wet",
    "persistent_dry",
    "dry_with_bursts",
    "flip_wet_to_dry",
    "flip_dry_to_wet",
]

# -----------------------------
# Helpers
# -----------------------------
def parse_months(months_str: str) -> List[int]:
    months = [int(x.strip()) for x in months_str.split(",") if x.strip()]
    for m in months:
        if m < 1 or m > 12:
            raise ValueError(f"Invalid month: {m}")
    return months

def season_month_day_list(months: List[int]) -> List[int]:
    """Return list of month numbers for each day in the season."""
    month_len = {1: 31, 2: 28, 3: 31, 4: 30, 5: 31, 6: 30, 7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31}
    out = []
    for m in months:
        out.extend([m] * month_len[m])
    return out

def safe_renormalize_row(row: np.ndarray) -> np.ndarray:
    row = np.clip(row, 0.0, None)
    s = row.sum()
    if s <= 0:
        return np.ones_like(row) / len(row)
    return row / s

def boost_diagonal(P: np.ndarray, idx: int, delta: float) -> np.ndarray:
    """Increase P[idx, idx] by delta and take mass proportionally from other cols."""
    P2 = P.copy()
    n = P.shape[1]
    delta = float(delta)
    if delta <= 0:
        return P2
    non_diag = [j for j in range(n) if j != idx]
    available = P2[idx, non_diag].sum()
    if available <= 1e-12:
        return P2
    take = min(delta, available)
    P2[idx, non_diag] *= (available - take) / available
    P2[idx, idx] += take
    P2[idx, :] = safe_renormalize_row(P2[idx, :])
    return P2

def boost_transition(P: np.ndarray, i: int, j: int, delta: float) -> np.ndarray:
    """Increase P[i, j] by delta and take mass proportionally from other destinations (excluding j)."""
    P2 = P.copy()
    n = P.shape[1]
    delta = float(delta)
    if delta <= 0:
        return P2
    others = [k for k in range(n) if k != j]
    available = P2[i, others].sum()
    if available <= 1e-12:
        return P2
    take = min(delta, available)
    P2[i, others] *= (available - take) / available
    P2[i, j] += take
    P2[i, :] = safe_renormalize_row(P2[i, :])
    return P2

def fit_transition_matrix(states: np.ndarray, n_states: int, breaks: Optional[np.ndarray] = None) -> Tuple[np.ndarray, np.ndarray]:
    """Fit transition counts/probabilities from integer state series."""
    counts = np.zeros((n_states, n_states), dtype=np.int64)
    T = len(states)
    if breaks is None:
        breaks = np.zeros(T - 1, dtype=bool)
    for t in range(T - 1):
        if breaks[t]:
            continue
        a = states[t]
        b = states[t + 1]
        if a < 0 or b < 0:
            continue
        counts[a, b] += 1

    probs = np.zeros_like(counts, dtype=float)
    for i in range(n_states):
        row_sum = counts[i].sum()
        probs[i] = counts[i] / row_sum if row_sum > 0 else np.ones(n_states) / n_states
    return counts, probs

def compute_run_lengths(states: np.ndarray) -> Dict[int, List[int]]:
    runs: Dict[int, List[int]] = {}
    if len(states) == 0:
        return runs
    current = states[0]
    length = 1
    for x in states[1:]:
        if x == current:
            length += 1
        else:
            runs.setdefault(current, []).append(length)
            current = x
            length = 1
    runs.setdefault(current, []).append(length)
    return runs

def switching_rate(states: np.ndarray) -> float:
    if len(states) < 2:
        return float("nan")
    return float(np.mean(states[1:] != states[:-1]))

def switching_rate_masked(states: np.ndarray, valid_mask: Optional[np.ndarray] = None) -> float:
    """Switching rate that safely ignores missing/invalid days."""
    if len(states) < 2:
        return float("nan")
    if valid_mask is None:
        valid_mask = (states >= 0)

    ok = valid_mask[:-1] & valid_mask[1:]
    if not np.any(ok):
        return float("nan")
    return float(np.mean(states[1:][ok] != states[:-1][ok]))


def compute_run_lengths_masked(states: np.ndarray, valid_mask: Optional[np.ndarray] = None) -> Dict[int, List[int]]:
    """Run lengths by state, splitting runs across invalid/missing days."""
    if len(states) == 0:
        return {}
    if valid_mask is None:
        valid_mask = (states >= 0)

    runs: Dict[int, List[int]] = {}
    current: Optional[int] = None
    length = 0

    for x, ok in zip(states, valid_mask):
        if not ok:
            if current is not None:
                runs.setdefault(current, []).append(length)
            current, length = None, 0
            continue

        xi = int(x)
        if current is None:
            current, length = xi, 1
        elif xi == current:
            length += 1
        else:
            runs.setdefault(current, []).append(length)
            current, length = xi, 1

    if current is not None:
        runs.setdefault(current, []).append(length)
    return runs


def make_season_date_index(year: int, months: List[int]) -> pd.DatetimeIndex:
    """Full daily date index for season months in a given year."""
    start = pd.Timestamp(year=year, month=months[0], day=1)
    end_month = months[-1]
    end = pd.Timestamp(year=year, month=end_month, day=1) + pd.offsets.MonthEnd(1)
    return pd.date_range(start, end, freq="D")


def stationary_dist(P: np.ndarray, tol: float = 1e-12, max_iter: int = 10000) -> np.ndarray:
    """Compute stationary distribution for a row-stochastic Markov matrix P."""
    n = P.shape[0]
    x = np.ones(n) / n
    for _ in range(max_iter):
        x2 = x @ P
        if np.max(np.abs(x2 - x)) < tol:
            return safe_renormalize_row(x2)
        x = x2
    return safe_renormalize_row(x)

def summarize_runs(runs: Dict[int, List[int]], n_states: int) -> pd.DataFrame:
    rows = []
    for s in range(n_states):
        arr = np.array(runs.get(s, []), dtype=float)
        if arr.size == 0:
            rows.append({"state": s, "mean": np.nan, "p95": np.nan, "n_runs": 0})
        else:
            rows.append({"state": s, "mean": arr.mean(), "p95": np.percentile(arr, 95), "n_runs": int(arr.size)})
    return pd.DataFrame(rows)

# -----------------------------
# Optional rainfall attachment
# -----------------------------
def _guess_date_col(columns: List[str]) -> Optional[str]:
    cols = [c.lower() for c in columns]
    for key in ["date", "time", "datetime"]:
        if key in cols:
            return columns[cols.index(key)]
    # common variations
    for c in columns:
        if "date" in c.lower():
            return c
    return None

def _guess_rain_col(columns: List[str]) -> Optional[str]:
    # Try to detect a rainfall / precipitation column.
    priority = ["daily_depth_mm", "depth_mm", "daily_rain_mm", "rain_mm", "rain", "rainfall", "precip_mm", "precip", "ppt", "prcp"]
    cols = [c.lower() for c in columns]
    for key in priority:
        if key in cols:
            return columns[cols.index(key)]
    for c in columns:
        lc = c.lower()
        if any(k in lc for k in ["rain", "precip", "prcp", "ppt"]):
            return c
    return None

def discover_daily_rainfall_file(rain_dir: Path) -> Optional[Path]:
    """Best-effort discovery of a daily rainfall file inside `rain_dir`.

    Looks for CSV/XLSX files whose headers include a date-like column and a rain-like column.
    If multiple candidates exist, returns the first good match.
    """
    if not rain_dir.exists():
        return None

    cands = list(rain_dir.rglob("*.csv")) + list(rain_dir.rglob("*.xlsx")) + list(rain_dir.rglob("*.xls"))
    # Prefer filenames that look like daily rainfall products
    def score(p: Path) -> int:
        name = p.name.lower()
        s = 0
        for k in ["rain", "precip", "prcp", "ppt", "daily"]:
            if k in name:
                s += 1
        return s
    cands = sorted(cands, key=score, reverse=True)

    for p in cands[:200]:  # cap for speed
        try:
            if p.suffix.lower() == ".csv":
                dfh = pd.read_csv(p, nrows=50)
            else:
                dfh = pd.read_excel(p, nrows=50)
        except Exception:
            continue
        date_col = _guess_date_col(list(dfh.columns))
        rain_col = _guess_rain_col(list(dfh.columns))
        if date_col and rain_col:
            return p
    return None

def load_daily_rainfall(path: Path, date_col: Optional[str] = None, rain_col: Optional[str] = None) -> pd.DataFrame:
    """Load daily rainfall series with columns: date, rain_mm."""
    if path.suffix.lower() == ".csv":
        df = pd.read_csv(path)
    else:
        df = pd.read_excel(path)

    if date_col is None:
        date_col = _guess_date_col(list(df.columns))
    if rain_col is None:
        rain_col = _guess_rain_col(list(df.columns))

    if date_col is None or rain_col is None:
        raise ValueError(
            f"Could not detect date/rain columns in {path.name}. Columns found: {list(df.columns)}"
        )

    out = df[[date_col, rain_col]].copy()
    out = out.rename(columns={date_col: "date", rain_col: "rain_mm"})
    out["date"] = pd.to_datetime(out["date"], errors="coerce")
    out["rain_mm"] = pd.to_numeric(out["rain_mm"], errors="coerce")
    out = out.dropna(subset=["date"]).sort_values("date")
    return out

def build_rain_pools_by_state_month(
    df_states: pd.DataFrame,
    rain_df: pd.DataFrame,
    months: List[int],
    n_states: int,
) -> Tuple[Dict[Tuple[int,int], np.ndarray], np.ndarray]:
    """Join rainfall to states and build empirical rainfall pools keyed by (state, month)."""
    m = df_states.merge(rain_df, on="date", how="left")
    m = m[m["month"].isin(months)].copy()

    pools: Dict[Tuple[int,int], np.ndarray] = {}
    for s in range(n_states):
        for mo in months:
            arr = m.loc[(m["state"] == s) & (m["month"] == mo), "rain_mm"].to_numpy()
            arr = arr[np.isfinite(arr)]
            if arr.size:
                pools[(s, mo)] = arr

    all_rain = m["rain_mm"].to_numpy()
    all_rain = all_rain[np.isfinite(all_rain)]
    return pools, all_rain

def sample_rainfall_for_sims(
    sims: np.ndarray,
    month_seq: List[int],
    pools: Dict[Tuple[int,int], np.ndarray],
    rng: np.random.Generator,
    fallback_month: Optional[Dict[int, np.ndarray]] = None,
    fallback_all: Optional[np.ndarray] = None,
) -> np.ndarray:
    """Sample rainfall for each simulated day using empirical pools by (state, month).

    This is a lightweight rainfall attachment for Step 3 timing/anchor-year diagnostics.
    It is NOT a full Step 4 driver-package sampler.
    """
    n_sims, L = sims.shape
    rain = np.full((n_sims, L), np.nan, dtype=float)

    for t, mo in enumerate(month_seq):
        st_col = sims[:, t]
        for s in np.unique(st_col):
            idx = np.where(st_col == s)[0]
            pool = pools.get((int(s), int(mo)))
            if pool is None or pool.size == 0:
                if fallback_month is not None and int(mo) in fallback_month and fallback_month[int(mo)].size:
                    pool = fallback_month[int(mo)]
                elif fallback_all is not None and fallback_all.size:
                    pool = fallback_all
                else:
                    continue
            rain[idx, t] = rng.choice(pool, size=idx.size, replace=True)

    return rain

def simulate_storyline_ensemble(
    P_overall: np.ndarray,
    P_monthly: Optional[Dict[int, np.ndarray]],
    months: List[int],
    start_dist: np.ndarray,
    n_sims: int,
    rng: np.random.Generator,
    flip: bool = False,
    flip_day: int = DEFAULT_FLIP_DAY,
    P_overall_late: Optional[np.ndarray] = None,
    P_monthly_late: Optional[Dict[int, np.ndarray]] = None,
) -> np.ndarray:
    month_seq = season_month_day_list(months)
    L = len(month_seq)
    sims = np.empty((n_sims, L), dtype=int)
    n_states = P_overall.shape[0]

    for s in range(n_sims):
        states = np.empty(L, dtype=int)
        states[0] = rng.choice(n_states, p=start_dist)
        for t in range(L - 1):
            m = month_seq[t]
            if flip and t >= flip_day and (P_overall_late is not None):
                P_use = (P_monthly_late[m] if P_monthly_late is not None else P_overall_late)
            else:
                P_use = (P_monthly[m] if P_monthly is not None else P_overall)
            states[t + 1] = rng.choice(n_states, p=P_use[states[t]])
        sims[s] = states
    return sims


def ensemble_metrics(
    sims: np.ndarray,
    n_states: int,
    conv_idx: int = 2,
    settled_idx: int = 3,
) -> Dict[str, object]:
    """Compute ensemble diagnostics for storyline simulations.

    This extends the original Step-3 diagnostics with *burst-sensitive* metrics that
    are needed to demonstrate 'Dry with storm outbreaks' behaviour:

    - n_runs_convective: number of Convective runs per season
    - mean_runlength_convective: mean Convective run length per season
    - transitions Settled→Convective and Convective→Settled (counts per season)

    Notes
    -----
    * These metrics are about *structure/timing* of convective outbreaks. Seasonal
      composition alone can miss them.
    """
    n_sims, L = sims.shape

    # Composition and persistence diagnostics
    days = np.zeros((n_sims, n_states), dtype=int)
    switch = np.zeros(n_sims, dtype=float)
    maxrun = np.zeros((n_sims, n_states), dtype=int)

    # Burst diagnostics (Convective outbreaks)
    n_runs_conv = np.zeros(n_sims, dtype=float)
    mean_runlen_conv = np.zeros(n_sims, dtype=float)
    n_set_to_conv = np.zeros(n_sims, dtype=float)
    n_conv_to_set = np.zeros(n_sims, dtype=float)

    for i in range(n_sims):
        st = sims[i]

        # Days in each group
        for s in range(n_states):
            days[i, s] = int(np.sum(st == s))

        # Overall switching rate
        switch[i] = switching_rate(st)

        # Run-length diagnostics
        runs = compute_run_lengths(st)
        for s in range(n_states):
            maxrun[i, s] = int(np.max(runs.get(s, [0])))

        # --- Burst diagnostics ---
        conv_runs = runs.get(conv_idx, [])
        n_runs_conv[i] = float(len(conv_runs))
        mean_runlen_conv[i] = float(np.mean(conv_runs)) if len(conv_runs) else 0.0

        # Directional alternation counts (per season)
        n_set_to_conv[i] = float(np.sum((st[:-1] == settled_idx) & (st[1:] == conv_idx)))
        n_conv_to_set[i] = float(np.sum((st[:-1] == conv_idx) & (st[1:] == settled_idx)))

    def q(x, p):
        return float(np.percentile(x, p))

    return {
        # composition
        "days_mean": days.mean(axis=0),
        "days_p05": np.percentile(days, 5, axis=0),
        "days_p95": np.percentile(days, 95, axis=0),

        # switching + persistence
        "switch_mean": float(np.mean(switch)),
        "switch_p05": q(switch, 5),
        "switch_p95": q(switch, 95),
        "maxrun_mean": maxrun.mean(axis=0),
        "maxrun_p95": np.percentile(maxrun, 95, axis=0),

        # burst-sensitive metrics
        "n_runs_conv_mean": float(np.mean(n_runs_conv)),
        "n_runs_conv_p05": q(n_runs_conv, 5),
        "n_runs_conv_p95": q(n_runs_conv, 95),

        "mean_runlen_conv_mean": float(np.mean(mean_runlen_conv)),
        "mean_runlen_conv_p05": q(mean_runlen_conv, 5),
        "mean_runlen_conv_p95": q(mean_runlen_conv, 95),

        "n_set_to_conv_mean": float(np.mean(n_set_to_conv)),
        "n_set_to_conv_p05": q(n_set_to_conv, 5),
        "n_set_to_conv_p95": q(n_set_to_conv, 95),

        "n_conv_to_set_mean": float(np.mean(n_conv_to_set)),
        "n_conv_to_set_p05": q(n_conv_to_set, 5),
        "n_conv_to_set_p95": q(n_conv_to_set, 95),

        "n_setconv_total_mean": float(np.mean(n_set_to_conv + n_conv_to_set)),
        "n_setconv_total_p05": q(n_set_to_conv + n_conv_to_set, 5),
        "n_setconv_total_p95": q(n_set_to_conv + n_conv_to_set, 95),
    }


def ensemble_wet_balance_halves(
    sims: np.ndarray,
    wet_states: List[int],
    split: int,
) -> Dict[str, float]:
    """Order-sensitive metric: wet fraction in first segment minus second segment.

    This is designed to distinguish flip storylines where the order matters.
    For example, with wet_states=[0,1] (Cyclonic + Showery), Wet→Dry should yield
    positive wetbalance_mean, and Dry→Wet should yield negative wetbalance_mean.

    Parameters
    ----------
    sims : (n_sims, L) array
        Simulated seasonal state sequences.
    wet_states : list of int
        State indices treated as 'wet/unsettled'.
    split : int
        Day index that splits the season into early and late segments.
    """
    n_sims, L = sims.shape
    split = int(max(1, min(split, L - 1)))

    wet_first = np.mean(np.isin(sims[:, :split], wet_states), axis=1)
    wet_second = np.mean(np.isin(sims[:, split:], wet_states), axis=1)
    balance = wet_first - wet_second

    return {
        "wetfrac_first_mean": float(np.mean(wet_first)),
        "wetfrac_first_p05": float(np.percentile(wet_first, 5)),
        "wetfrac_first_p95": float(np.percentile(wet_first, 95)),
        "wetfrac_second_mean": float(np.mean(wet_second)),
        "wetfrac_second_p05": float(np.percentile(wet_second, 5)),
        "wetfrac_second_p95": float(np.percentile(wet_second, 95)),
        "wetbalance_mean": float(np.mean(balance)),
        "wetbalance_p05": float(np.percentile(balance, 5)),
        "wetbalance_p95": float(np.percentile(balance, 95)),
    }

# -----------------------------
# Anchor-year plausibility check
# -----------------------------
def season_metrics_from_arrays(
    states: np.ndarray,
    wet_states: List[int],
    split: int,
    n_states: int,
    conv_idx: int = 2,
    settled_idx: int = 3,
    rain_mm: Optional[np.ndarray] = None,
    heavy_rain_thresh: Optional[float] = None,
) -> Dict[str, float]:
    """Compute Step-3 diagnostics for a single observed season (handles missing states as -1)."""
    valid = (states >= 0)

    # Composition
    days = np.array([np.sum(valid & (states == s)) for s in range(n_states)], dtype=float)

    # Switching
    sw = switching_rate_masked(states, valid_mask=valid)

    # Run lengths + max run
    runs = compute_run_lengths_masked(states, valid_mask=valid)
    maxrun = np.array([np.max(runs.get(s, [0])) for s in range(n_states)], dtype=float)

    # Convective outbreaks
    conv_runs = runs.get(conv_idx, [])
    n_runs_conv = float(len(conv_runs))
    mean_runlen_conv = float(np.mean(conv_runs)) if len(conv_runs) else 0.0
    n_set_to_conv = float(np.sum(valid[:-1] & valid[1:] & (states[:-1] == settled_idx) & (states[1:] == conv_idx)))
    n_conv_to_set = float(np.sum(valid[:-1] & valid[1:] & (states[:-1] == conv_idx) & (states[1:] == settled_idx)))
    n_setconv_total = n_set_to_conv + n_conv_to_set

    # Timing: wet fractions early/late
    L = len(states)
    split = int(max(1, min(split, L - 1)))
    v1 = valid[:split]
    v2 = valid[split:]
    wet_first = float(np.mean(np.isin(states[:split][v1], wet_states))) if np.any(v1) else float("nan")
    wet_second = float(np.mean(np.isin(states[split:][v2], wet_states))) if np.any(v2) else float("nan")
    wetbalance = wet_first - wet_second if np.isfinite(wet_first) and np.isfinite(wet_second) else float("nan")

    out: Dict[str, float] = {
        **{f"days_{s}": float(days[s]) for s in range(n_states)},
        "switch": float(sw),
        **{f"maxrun_{s}": float(maxrun[s]) for s in range(n_states)},
        "n_runs_conv": n_runs_conv,
        "mean_runlen_conv": mean_runlen_conv,
        "n_set_to_conv": n_set_to_conv,
        "n_conv_to_set": n_conv_to_set,
        "n_setconv_total": n_setconv_total,
        "wetfrac_first": wet_first,
        "wetfrac_second": wet_second,
        "wetbalance": wetbalance,
    }

    if rain_mm is not None:
        rain_mm = np.asarray(rain_mm, dtype=float)
        r1 = rain_mm[:split]
        r2 = rain_mm[split:]
        out["rain_mean_first"] = float(np.nanmean(r1)) if np.isfinite(r1).any() else float("nan")
        out["rain_mean_second"] = float(np.nanmean(r2)) if np.isfinite(r2).any() else float("nan")
        out["rain_balance_first_minus_second"] = out["rain_mean_first"] - out["rain_mean_second"] if np.isfinite(out["rain_mean_first"]) and np.isfinite(out["rain_mean_second"]) else float("nan")

        if heavy_rain_thresh is not None and np.isfinite(heavy_rain_thresh):
            out["n_heavy_rain_first"] = float(np.nansum(r1 >= heavy_rain_thresh))
            out["n_heavy_rain_second"] = float(np.nansum(r2 >= heavy_rain_thresh))
            out["n_heavy_rain_total"] = out["n_heavy_rain_first"] + out["n_heavy_rain_second"]

    return out


def compute_anchor_year_metrics(
    df_states: pd.DataFrame,
    months: List[int],
    years: List[int],
    wet_states: List[int],
    split: int,
    n_states: int,
    rain_df: Optional[pd.DataFrame] = None,
    heavy_rain_thresh: Optional[float] = None,
) -> pd.DataFrame:
    rows = []
    for yr in years:
        idx = make_season_date_index(yr, months)
        base = pd.DataFrame({"date": idx})
        base["month"] = base["date"].dt.month
        base["year"] = base["date"].dt.year

        d = df_states[(df_states["year"] == yr) & (df_states["month"].isin(months))][["date", "state"]].copy()
        d["date"] = pd.to_datetime(d["date"])
        base = base.merge(d, on="date", how="left")
        base["state"] = base["state"].fillna(-1).astype(int)

        rain_arr = None
        if rain_df is not None:
            r = rain_df.copy()
            r = r[(r["date"].dt.year == yr) & (r["date"].dt.month.isin(months))]
            base = base.merge(r, on="date", how="left")
            rain_arr = base["rain_mm"].to_numpy(dtype=float)

        met = season_metrics_from_arrays(
            states=base["state"].to_numpy(dtype=int),
            wet_states=wet_states,
            split=split,
            n_states=n_states,
            rain_mm=rain_arr,
            heavy_rain_thresh=heavy_rain_thresh,
        )
        met["year"] = int(yr)
        met["n_days_valid"] = int(np.sum(base["state"].to_numpy(dtype=int) >= 0))
        rows.append(met)
    return pd.DataFrame(rows)


def plot_anchor_year_plausibility(
    metrics_df: pd.DataFrame,
    anchor_df: pd.DataFrame,
    outpath: Path,
    story_order: List[str],
    labels: Optional[Dict[str, str]] = None,
):
    """Overlay anchor-year observed metrics on storyline ensemble envelopes."""
    d = metrics_df.set_index("storyline_code").loc[story_order].reset_index()

    def lab(code: str) -> str:
        if labels and code in labels:
            return labels[code]
        return code

    x = np.arange(len(story_order))

    panels = [
        ("Switching rate", "switch_mean", "switch_p05", "switch_p95", "switch", True),
        ("Max run (Settled)", "maxrun_mean_3", "maxrun_p95_3", None, "maxrun_3", False),
        ("Max run (Cyclonic)", "maxrun_mean_0", "maxrun_p95_0", None, "maxrun_0", False),
        ("Convective runs", "n_runs_conv_mean", "n_runs_conv_p05", "n_runs_conv_p95", "n_runs_conv", True),
        ("Settled↔Convective transitions", "n_setconv_total_mean", "n_setconv_total_p05", "n_setconv_total_p95", "n_setconv_total", True),
        ("Wet timing balance (first−second)", "wetbalance_mean", "wetbalance_p05", "wetbalance_p95", "wetbalance", True),
    ]

    if "rain_mean_first_mean" in d.columns and "rain_mean_first" in anchor_df.columns:
        panels.append(("Rain mean (first half)", "rain_mean_first_mean", "rain_mean_first_p05", "rain_mean_first_p95", "rain_mean_first", True))
        panels.append(("Rain mean (second half)", "rain_mean_second_mean", "rain_mean_second_p05", "rain_mean_second_p95", "rain_mean_second", True))

    n = len(panels)
    ncols = 3
    nrows = int(np.ceil(n / ncols))

    fig, axes = plt.subplots(nrows, ncols, figsize=(5.2 * ncols, 3.8 * nrows), constrained_layout=True)
    axes = np.atleast_1d(axes).ravel()

    for ax, (title, mean_col, p05_col, p95_col, anchor_col, has_full_env) in zip(axes, panels):
        mean = d[mean_col].to_numpy()

        if p95_col is None:
            upper = d[p05_col].to_numpy()  # stored as p95 for maxrun in v10+
            ax.plot(x, mean, marker="o", linestyle="-", label="Ensemble mean")
            ax.scatter(x, upper, marker="x", label="Ensemble p95 (max run)")
        else:
            lower = d[p05_col].to_numpy()
            upper = d[p95_col].to_numpy()
            ax.plot(x, mean, marker="o", linestyle="-", label="Ensemble mean")
            ax.vlines(x, lower, upper, linewidth=2, label="Envelope (5–95%)")

        # Anchor-year points (plotted at baseline x=0 for readability)
        xb = 0
        for _, r in anchor_df.iterrows():
            y = r.get(anchor_col, np.nan)
            if np.isfinite(y):
                ax.scatter([xb], [y], marker="D", s=45, label=f"Observed {int(r['year'])}")

        ax.set_xticks(x)
        ax.set_xticklabels([lab(k) for k in story_order], rotation=15, ha="right")
        ax.set_title(title)
        ax.grid(True, axis="y", alpha=0.3)

    # Deduplicate legend entries (across first axis)
    handles, labels_ = axes[0].get_legend_handles_labels()
    uniq = {}
    for h, l in zip(handles, labels_):
        uniq[l] = h
    fig.legend(list(uniq.values()), list(uniq.keys()), loc="upper center", ncol=5, frameon=False)
    fig.suptitle("Anchor-year plausibility check: observed summers vs storyline ensemble envelopes", fontsize=14)
    fig.savefig(outpath, dpi=200)
    plt.close(fig)

def plot_storyline_matrices(
    story_mats: Dict[str, np.ndarray],
    outpath: Path,
    title: str,
    labels: Optional[Dict[str, str]] = None,
    order: Optional[List[str]] = None,
):
    """Plot one row of transition matrices. Uses `labels` for titles if provided."""
    keys = order if order is not None else list(story_mats.keys())
    n = len(keys)
    fig, axes = plt.subplots(1, n, figsize=(4.2 * n, 4.2), constrained_layout=True)
    if n == 1:
        axes = [axes]

    vmin, vmax = 0.0, 1.0
    im = None

    def disp(k: str) -> str:
        if labels and k in labels:
            return labels[k]
        return k.replace("_", " ")

    for ax, k in zip(axes, keys):
        im = ax.imshow(story_mats[k], vmin=vmin, vmax=vmax)
        ax.set_title(disp(k))
        ax.set_xticks(range(len(GROUP_ORDER)))
        ax.set_yticks(range(len(GROUP_ORDER)))
        ax.set_xticklabels([g.split(" (")[0] for g in GROUP_ORDER], rotation=45, ha="right")
        ax.set_yticklabels([g.split(" (")[0] for g in GROUP_ORDER])
        for i in range(4):
            for j in range(4):
                ax.text(j, i, f"{story_mats[k][i, j]:.2f}", ha="center", va="center", fontsize=9)

    cbar = fig.colorbar(im, ax=axes, shrink=0.85)
    cbar.set_label("P(next state)")
    fig.suptitle(title, fontsize=14)
    fig.savefig(outpath, dpi=200)
    plt.close(fig)



def plot_flip_transition_matrices(
    P_wet: np.ndarray,
    P_dry: np.ndarray,
    outpath: Path,
    group_order: Optional[List[str]] = None,
):
    """Plot the two-phase ("flip") transition behaviour explicitly.

    This figure is the *proof* that Wet→Dry and Dry→Wet differ: they use the same two
    component matrices, but in opposite order across the season.
    """
    if group_order is None:
        group_order = GROUP_ORDER

    fig, axes = plt.subplots(2, 2, figsize=(12, 7), constrained_layout=True)

    panels = [
        ("Wet → Dry (first half)", P_wet),
        ("Wet → Dry (second half)", P_dry),
        ("Dry → Wet (first half)", P_dry),
        ("Dry → Wet (second half)", P_wet),
    ]

    vmin, vmax = 0.0, 1.0
    for ax, (title, P) in zip(axes.flat, panels):
        im = ax.imshow(P, vmin=vmin, vmax=vmax)
        ax.set_title(title, fontsize=11)
        ax.set_xticks(range(len(group_order)))
        ax.set_yticks(range(len(group_order)))
        ax.set_xticklabels(group_order, rotation=45, ha="right")
        ax.set_yticklabels(group_order)

        # annotate values
        for i in range(P.shape[0]):
            for j in range(P.shape[1]):
                ax.text(j, i, f"{P[i, j]:.2f}", ha="center", va="center", fontsize=9)

    # shared colorbar
    cbar = fig.colorbar(im, ax=axes.ravel().tolist(), fraction=0.035, pad=0.02)
    cbar.set_label("P(next state)")

    fig.suptitle("Two-phase (flip) storylines: component transition matrices used in each half-season", fontsize=13)
    fig.savefig(outpath, dpi=200)
    plt.close(fig)

def plot_storyline_diagnostics(
    metrics_df: pd.DataFrame,
    outpath: Path,
    season_len: int,
    order: Optional[List[str]] = None,
    labels: Optional[Dict[str, str]] = None,
):
    """Paper-ready diagnostics for Step 3 storylines.

    Panels
    ------
    A) Seasonal composition (days in each synoptic family)
    B) Max run length by family (mean and p95)
    C) Switching rate (mean and 5–95%)
    D) Flip-direction diagnostic: early-season wetness minus late-season wetness
       *Wetness here is defined as all non-settled states (Cyclonic+Showery+Convective).*
       This avoids under-counting convective storm wetness.
    E) Storm-outbreak diagnostics:
       - number of Convective runs per season (mean and 5–95%)
       - Settled↔Convective transition count per season (mean and 5–95%)
    """
    if order is None:
        story_order = list(metrics_df["storyline_code"].unique())
    else:
        story_order = order

    n_states = 4

    # Layout: 3 rows x 2 columns; Panel E spans the full bottom row.
    fig = plt.figure(figsize=(15, 11), constrained_layout=True)
    gs = fig.add_gridspec(3, 2)
    axA = fig.add_subplot(gs[0, 0])
    axB = fig.add_subplot(gs[0, 1])
    axC = fig.add_subplot(gs[1, 0])
    axD = fig.add_subplot(gs[1, 1])
    axE = fig.add_subplot(gs[2, :])

    def lab(code: str) -> str:
        if labels and code in labels:
            return labels[code]
        return code.replace("_", " ")

    # Reindex metrics_df to match desired order
    d = metrics_df.set_index("storyline_code").loc[story_order].reset_index()

    x = np.arange(len(story_order))
    width = 0.18

    # ---- Panel A: composition ----
    for s in range(n_states):
        mean = d[f"days_mean_{s}"].values
        p05 = d[f"days_p05_{s}"].values
        p95 = d[f"days_p95_{s}"].values
        axA.bar(x + (s - 1.5) * width, mean, width=width, label=GROUP_ORDER[s])
        axA.vlines(x + (s - 1.5) * width, p05, p95)
    axA.set_xticks(x)
    axA.set_xticklabels([lab(k) for k in story_order], rotation=15, ha="right")
    axA.set_ylabel("Days in group (per season)")
    axA.set_title("A) Season composition by storyline (mean; lines=5–95%)")
    axA.legend(fontsize=9)

    # ---- Panel B: max run length ----
    for s in range(n_states):
        mean = d[f"maxrun_mean_{s}"].values
        p95 = d[f"maxrun_p95_{s}"].values
        axB.plot(x, mean, marker="o", label=GROUP_ORDER[s])
        axB.scatter(x, p95, marker="x")
    axB.set_xticks(x)
    axB.set_xticklabels([lab(k) for k in story_order], rotation=15, ha="right")
    axB.set_ylabel("Days")
    axB.set_title("B) Max run length (line=mean; x=p95)")
    axB.legend(fontsize=9)

    # ---- Panel C: switching ----
    axC.bar(x, d["switch_mean"].values)
    axC.vlines(x, d["switch_p05"].values, d["switch_p95"].values)
    axC.set_xticks(x)
    axC.set_xticklabels([lab(k) for k in story_order], rotation=15, ha="right")
    axC.set_ylabel("P(change next day)")
    axC.set_ylim(0, 1)
    axC.set_title("C) Switching rate (mean; lines=5–95%)")

    # ---- Panel D: timing diagnostic (early vs late wetness) ----
    # For "flip" storylines, totals can look similar because the scenario is about *when* wet days occur,
    # not necessarily changing the seasonal mean. The correct diagnostic is therefore early vs late.
    if {"wetfrac_first_mean", "wetfrac_second_mean"}.issubset(set(d.columns)):
        w = 0.35
        axD.bar(x - w/2, d["wetfrac_first_mean"].values, width=w, label="First half")
        axD.vlines(x - w/2, d["wetfrac_first_p05"].values, d["wetfrac_first_p95"].values)

        axD.bar(x + w/2, d["wetfrac_second_mean"].values, width=w, label="Second half")
        axD.vlines(x + w/2, d["wetfrac_second_p05"].values, d["wetfrac_second_p95"].values)

        axD.set_xticks(x)
        axD.set_xticklabels([lab(k) for k in story_order], rotation=15, ha="right")
        axD.set_ylabel("Wet fraction")
        axD.set_ylim(0, 1)
        axD.set_title("D) Timing diagnostic: wet fraction in first vs second half (mean; lines=5–95%)")
        axD.legend(fontsize=9)
    elif "wetbalance_mean" in d.columns:
        # Fallback (older outputs): plot early-late balance only
        axD.axhline(0.0, linewidth=1)
        axD.bar(x, d["wetbalance_mean"].values)
        axD.vlines(x, d["wetbalance_p05"].values, d["wetbalance_p95"].values)
        axD.set_xticks(x)
        axD.set_xticklabels([lab(k) for k in story_order], rotation=15, ha="right")
        axD.set_ylabel("Wet fraction (early − late)")
        axD.set_title("D) Timing diagnostic (fallback): wet fraction balance (mean; lines=5–95%)")
    else:
        axD.text(0.5, 0.5, "Timing diagnostic not available", ha="center", va="center")
        axD.set_axis_off()

# ---- Panel E: outbreak-sensitive metrics ----
    # Convective runs per season
    if ("n_runs_conv_mean" in d.columns) and ("n_setconv_total_mean" in d.columns):
        axE.bar(x - 0.15, d["n_runs_conv_mean"].values, width=0.3, label="Convective runs / season")
        axE.vlines(x - 0.15, d["n_runs_conv_p05"].values, d["n_runs_conv_p95"].values)

        # Settled↔Convective transition counts (both directions summed)
        axE.bar(x + 0.15, d["n_setconv_total_mean"].values, width=0.3, label="Settled↔Convective transitions / season")
        axE.vlines(x + 0.15, d["n_setconv_total_p05"].values, d["n_setconv_total_p95"].values)

        # Optional: annotate mean convective run length (use a line on a second axis to keep units interpretable)
        if "mean_runlen_conv_mean" in d.columns:
            axE2 = axE.twinx()
            axE2.plot(x, d["mean_runlen_conv_mean"].values, marker="o", linestyle="--", label="Mean Convective run length")
            axE2.set_ylabel("Mean convective run length (days)")
            # Combine legends
            h1, l1 = axE.get_legend_handles_labels()
            h2, l2 = axE2.get_legend_handles_labels()
            axE2.legend(h1 + h2, l1 + l2, fontsize=9, loc="upper right")
        else:
            axE.legend(fontsize=9, loc="upper right")

        axE.set_xticks(x)
        axE.set_xticklabels([lab(k) for k in story_order], rotation=15, ha="right")
        axE.set_ylabel("Count per season")
        axE.set_title("E) Storm-outbreak diagnostics (mean; lines=5–95%)")
    else:
        axE.text(0.5, 0.5, "Outbreak diagnostics not available", ha="center", va="center")
        axE.set_axis_off()

    fig.suptitle(f"Step 3 Storyline diagnostics (season length = {season_len} days)", fontsize=14)
    fig.savefig(outpath, dpi=200)
    plt.close(fig)


def plot_mechanism_persistence(
    P_base: np.ndarray,
    P_wet: np.ndarray,
    P_dry: np.ndarray,
    metrics_df: pd.DataFrame,
    outpath: Path,
    labels: Optional[Dict[str, str]] = None,
):
    """Mechanism figure: persistence storylines (diagonals + run-length response)."""
    idx = {name: i for i, name in enumerate(GROUP_ORDER)}
    diag = pd.DataFrame({
        "state": GROUP_ORDER,
        "baseline": np.diag(P_base),
        "persistent_wet": np.diag(P_wet),
        "persistent_dry": np.diag(P_dry),
    })
    d = metrics_df.set_index("storyline_code")

    fig, axes = plt.subplots(2, 1, figsize=(12, 7), constrained_layout=True)

    x = np.arange(len(GROUP_ORDER))
    w = 0.25
    axes[0].bar(x - w, diag["baseline"], width=w, label="Baseline")
    axes[0].bar(x, diag["persistent_wet"], width=w, label="Persistent wet")
    axes[0].bar(x + w, diag["persistent_dry"], width=w, label="Persistent dry")
    axes[0].set_xticks(x)
    axes[0].set_xticklabels([g.split(" (")[0] for g in GROUP_ORDER], rotation=15, ha="right")
    axes[0].set_ylabel("P(stay in same family)")
    axes[0].set_title("Mechanism: persistence is implemented by boosting diagonal transition probabilities")
    axes[0].set_ylim(0, 1)
    axes[0].legend()

    for s in [idx["Cyclonic Atlantic (frontal)"], idx["Settled anticyclonic quiet"]]:
        axes[1].plot(
            ["baseline", "persistent_wet", "persistent_dry"],
            [d.loc[k, f"maxrun_mean_{s}"] for k in ["baseline", "persistent_wet", "persistent_dry"]],
            marker="o",
            label=f"Max run mean: {GROUP_ORDER[s].split(' (')[0]}",
        )
    axes[1].set_ylabel("Days")
    axes[1].set_title("Mechanism response: increased persistence produces longer runs")
    axes[1].grid(True, axis="y", alpha=0.3)
    axes[1].legend()

    fig.savefig(outpath, dpi=200)
    plt.close(fig)


def plot_mechanism_storm_outbreaks(
    metrics_df: pd.DataFrame,
    outpath: Path,
    labels: Optional[Dict[str, str]] = None,
):
    """Mechanism figure: storm-outbreak storylines (runs + alternation metrics)."""
    d = metrics_df.set_index("storyline_code")
    keys = ["baseline", "persistent_dry", "dry_with_bursts"]
    keys = [k for k in keys if k in d.index]
    x = np.arange(len(keys))

    fig, ax = plt.subplots(1, 1, figsize=(11, 4.8), constrained_layout=True)

    ax.bar(x - 0.2, [d.loc[k, "n_runs_conv_mean"] for k in keys], width=0.35, label="Convective runs / season")
    ax.vlines(x - 0.2, [d.loc[k, "n_runs_conv_p05"] for k in keys], [d.loc[k, "n_runs_conv_p95"] for k in keys])

    ax.bar(x + 0.2, [d.loc[k, "n_setconv_total_mean"] for k in keys], width=0.35, label="Settled↔Convective transitions / season")
    ax.vlines(x + 0.2, [d.loc[k, "n_setconv_total_p05"] for k in keys], [d.loc[k, "n_setconv_total_p95"] for k in keys])

    ax2 = ax.twinx()
    ax2.plot(x, [d.loc[k, "mean_runlen_conv_mean"] for k in keys], marker="o", linestyle="--", label="Mean Convective run length")
    ax2.set_ylabel("Mean convective run length (days)")

    ax.set_xticks(x)
    ax.set_xticklabels([labels.get(k, k) if labels else k for k in keys], rotation=10, ha="right")
    ax.set_ylabel("Count per season")
    ax.set_title("Mechanism: outbreaks differ by clustering/alternation, not necessarily by mean Convective occupancy")
    ax.grid(True, axis="y", alpha=0.3)

    h1, l1 = ax.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax2.legend(h1 + h2, l1 + l2, loc="upper right", frameon=False)

    fig.savefig(outpath, dpi=200)
    plt.close(fig)


def plot_mechanism_flip_timing(
    metrics_df: pd.DataFrame,
    outpath: Path,
    labels: Optional[Dict[str, str]] = None,
):
    """Mechanism figure: flip storylines are timing stress tests (first vs second half)."""
    d = metrics_df.set_index("storyline_code")
    keys = [k for k in ["baseline", "flip_wet_to_dry", "flip_dry_to_wet"] if k in d.index]
    x = np.arange(len(keys))
    w = 0.35

    fig, ax = plt.subplots(1, 1, figsize=(11, 4.8), constrained_layout=True)
    ax.bar(x - w/2, [d.loc[k, "wetfrac_first_mean"] for k in keys], width=w, label="Wet fraction (first half)")
    ax.vlines(x - w/2, [d.loc[k, "wetfrac_first_p05"] for k in keys], [d.loc[k, "wetfrac_first_p95"] for k in keys])

    ax.bar(x + w/2, [d.loc[k, "wetfrac_second_mean"] for k in keys], width=w, label="Wet fraction (second half)")
    ax.vlines(x + w/2, [d.loc[k, "wetfrac_second_p05"] for k in keys], [d.loc[k, "wetfrac_second_p95"] for k in keys])

    ax.set_ylim(0, 1)
    ax.set_ylabel("Fraction of days that are non-Settled (Cyclonic+Showery+Convective)")
    ax.set_xticks(x)
    ax.set_xticklabels([labels.get(k, k) if labels else k for k in keys], rotation=10, ha="right")
    ax.set_title("Mechanism: flips test *when* wet pressure occurs, not necessarily the seasonal total")
    ax.grid(True, axis="y", alpha=0.3)

    if "rain_mean_first_mean" in d.columns and np.isfinite(d.loc[keys[0], "rain_mean_first_mean"]):
        ax2 = ax.twinx()
        ax2.plot(x, [d.loc[k, "rain_mean_first_mean"] for k in keys], marker="o", linestyle="--", label="Rain mean (first half)")
        ax2.plot(x, [d.loc[k, "rain_mean_second_mean"] for k in keys], marker="s", linestyle="--", label="Rain mean (second half)")
        ax2.set_ylabel("Rainfall (mm/day, sampled from observed distributions)")
        h1, l1 = ax.get_legend_handles_labels()
        h2, l2 = ax2.get_legend_handles_labels()
        ax2.legend(h1 + h2, l1 + l2, loc="upper right", frameon=False)
    else:
        ax.legend(frameon=False, loc="upper right")

    fig.savefig(outpath, dpi=200)
    plt.close(fig)

def make_storyline_matrices(
    baseline_overall: np.ndarray,
    baseline_monthly: Optional[Dict[int, np.ndarray]],
    use_monthly: bool,
    months: List[int],
    delta_persist: float,
    delta_burst: float,
    delta_return: float,
    delta_dry_entry: Optional[float] = None,
) -> Dict[str, Tuple[np.ndarray, Optional[Dict[int, np.ndarray]]]]:
    """
    Build perturbed transition matrices for storylines.

    delta_dry_entry controls the strength of "entry" into Settled from other states in the dry storylines.
    If None, it defaults to 0.7*delta_persist.

    Returns a dict mapping storyline codes to (P_overall, P_monthly_or_None).
    Also returns two component matrices used for two-phase seasons:
      - flip_component_wet: persistence boosted for Cyclonic + Showery
      - flip_component_dry: persistence boosted for Settled
    """
    idx = {name: i for i, name in enumerate(GROUP_ORDER)}
    i_cyc = idx["Cyclonic Atlantic (frontal)"]
    i_show = idx["Showery maritime / unsettled"]
    i_conv = idx["Convective extremes"]
    i_set = idx["Settled anticyclonic quiet"]

    def apply_to_matrix(P: np.ndarray, fn) -> np.ndarray:
        P2 = fn(P.copy())
        for r in range(P2.shape[0]):
            P2[r] = safe_renormalize_row(P2[r])
        return P2

    def per_month_apply(fn):
        if not use_monthly or baseline_monthly is None:
            return None
        return {m: apply_to_matrix(baseline_monthly[m], fn) for m in months}

    story: Dict[str, Tuple[np.ndarray, Optional[Dict[int, np.ndarray]]]] = {}

    # 1) Observed transition (baseline)
    story["baseline"] = (
        baseline_overall.copy(),
        {m: baseline_monthly[m].copy() for m in months} if (use_monthly and baseline_monthly) else None,
    )

    # Helper perturbations
    def fn_wet(P):
        # Boost persistence in Cyclonic and Showery, and encourage swapping within wet family
        P = boost_diagonal(P, i_cyc, delta_persist)
        P = boost_diagonal(P, i_show, delta_persist)
        P = boost_transition(P, i_cyc, i_show, delta_persist * 0.3)
        P = boost_transition(P, i_show, i_cyc, delta_persist * 0.3)
        return P

    def fn_dry(P):
        # Option B dry storyline: shift toward anticyclonic dominance by increasing BOTH:
        #  (i) persistence of Settled (stay Settled once there), and
        #  (ii) transitions INTO Settled from other states (enter Settled more often).
        P = boost_diagonal(P, i_set, delta_persist)

        entry = (0.7 * delta_persist) if (delta_dry_entry is None) else float(delta_dry_entry)
        # Pull probability mass toward Settled from the other states.
        # Strongest for Cyclonic and Showery; weaker for Convective.
        P = boost_transition(P, i_cyc, i_set, entry)
        P = boost_transition(P, i_show, i_set, entry)
        P = boost_transition(P, i_conv, i_set, 0.5 * entry)
        return P

    def fn_dry_with_bursts(P):
        # Start from the dry-dominant matrix, then increase Settled→Convective bursts.
        P = fn_dry(P)
        # Storm outbreaks: encourage breakdown from Settled to Convective, and quick return to Settled.
        P = boost_transition(P, i_set, i_conv, delta_burst)
        P = boost_transition(P, i_conv, i_set, delta_return)
        return P

    # 2) Persistent wet
    story["persistent_wet"] = (apply_to_matrix(baseline_overall, fn_wet), per_month_apply(fn_wet))

    # 3) Persistent dry
    story["persistent_dry"] = (apply_to_matrix(baseline_overall, fn_dry), per_month_apply(fn_dry))

    # 4) Dry with storm outbreaks
    story["dry_with_bursts"] = (apply_to_matrix(baseline_overall, fn_dry_with_bursts), per_month_apply(fn_dry_with_bursts))

    # Components for two-phase seasons
    story["flip_component_wet"] = (apply_to_matrix(baseline_overall, fn_wet), per_month_apply(fn_wet))
    story["flip_component_dry"] = (apply_to_matrix(baseline_overall, fn_dry), per_month_apply(fn_dry))

    return story

def main():
    ap = argparse.ArgumentParser(description="Step 3: Arnell-style storylines by perturbing a 4-state Markov model.")
    ap.add_argument("--base-dir", type=str, default=str(DEFAULT_BASE_DIR), help="Folder containing classifications_30regimes*.csv (default: current working directory)")
    ap.add_argument("--classifications", type=str, default="", help="Optional explicit path to classification CSV")
    ap.add_argument("--start-year", type=int, default=DEFAULT_START_YEAR)
    ap.add_argument("--end-year", type=int, default=DEFAULT_END_YEAR)
    ap.add_argument("--months", type=str, default=",".join(str(m) for m in DEFAULT_MONTHS))
    ap.add_argument("--no-monthly", action="store_true", help="Use a single overall matrix (no month-specific matrices)")
    ap.add_argument("--n-sims", type=int, default=DEFAULT_N_SIMS)
    ap.add_argument("--seed", type=int, default=DEFAULT_RANDOM_SEED)

    ap.add_argument("--out-tag", type=str, default="v11_AprSep", help="Tag added to output folder to avoid overwriting previous runs")

    ap.add_argument("--delta-persist", type=float, default=DEFAULT_DELTA_PERSIST)
    ap.add_argument("--delta-dry-entry", type=float, default=None,
                    help="Extra probability mass shifted INTO Settled from other states in dry storylines. "
                         "If None, defaults to 0.7*delta_persist.")
    ap.add_argument("--delta-burst", type=float, default=DEFAULT_DELTA_BURST)
    ap.add_argument("--delta-return", type=float, default=DEFAULT_DELTA_RETURN)
    ap.add_argument("--flip-day", type=int, default=DEFAULT_FLIP_DAY)
    ap.add_argument("--flip-mode", type=str, default="both", choices=["both", "wet_to_dry", "dry_to_wet"],
                    help="Which two-phase season(s) to run: both (default), wet_to_dry, or dry_to_wet.")
    ap.add_argument("--flip-direction", type=str, default=None, choices=["wet_to_settled", "settled_to_wet"],
                    help="(Deprecated) Use --flip-mode. Kept for backwards compatibility.")
    # --- Reproducibility / non-overwriting outputs ---
    ap.add_argument("--run-id", type=str, default="", help="Optional run identifier appended to the output folder. Default: timestamp.")
    ap.add_argument("--out-root", type=str, default="", help="Optional output root directory. Default: base-dir.")

    # --- Anchor-year plausibility check (recommended for reviewer defence) ---
    ap.add_argument("--anchor-years", type=str, default="2012,2018,2022,2023",
                    help="Comma-separated list of historical anchor years for plausibility overlay (default: 2012,2018,2022,2023).")

    # --- Optional rainfall attachment for timing diagnostics (Step 3+; does not change the Markov generator) ---
    ap.add_argument("--attach-rainfall", action="store_true", default=DEFAULT_ATTACH_RAINFALL,
                    help="Attempt to attach rainfall to simulations using observed distributions by (family, month).")
    ap.add_argument("--no-attach-rainfall", action="store_true", help="Disable rainfall attachment even if rainfall paths are set.")
    ap.add_argument("--rain-dir", type=str, default=DEFAULT_RAIN_DIR, help="Folder containing daily rainfall or histogram inputs.")
    ap.add_argument("--rain-summary-xlsx", type=str, default=DEFAULT_RAIN_SUMMARY_XLSX, help="Optional rainfall summary-stats workbook for traceability.")
    ap.add_argument("--rain-daily", type=str, default="", help="Optional explicit daily rainfall file (CSV/XLSX). If empty, auto-discover under --rain-dir.")
    ap.add_argument("--heavy-rain-q", type=float, default=DEFAULT_HEAVY_RAIN_Q, help="Quantile for heavy-rain threshold, computed from observed May–Sep rainfall.")

    # --- Optional initialisation mode (helps avoid 'initial state drag' in dry storylines) ---
    ap.add_argument("--init-mode", type=str, default="observed_start_month",
                    choices=["observed_start_month", "stationary_overall", "stationary_first_month"],
                    help="How to set the day-1 state distribution for simulations.")

    args = ap.parse_args()

    base_dir = Path(args.base_dir)
    months = parse_months(args.months)
    use_monthly = not args.no_monthly

    suffix = "_monthly" if use_monthly else "_overall"

    # Always create a unique output folder (never overwrite), for reproducibility.
    # If you want a specific label, pass --run-id; otherwise we append a timestamp.
    run_id = args.run_id.strip() or datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

    out_root = Path(args.out_root) if args.out_root else base_dir
    out_dir = out_root / f"outputs_step3_storylines_{args.out_tag}_{args.start_year}_{args.end_year}_m{'-'.join(map(str, months))}{suffix}_{run_id}"
    out_dir.mkdir(parents=True, exist_ok=True)

    # --- Transparent disclaimer: storylines are *stress tests* (plausible, not probabilistic) ---
    # This is a code-level note for reviewer defence; you can paste the text into Methods if needed.
    disclaimer = (
        "Storylines are stress tests (Arnell-style plausible storylines), not probabilistic forecasts.\n"
        "Step 3 perturbs a Markov transition model to explore persistence/timing/clustering mechanisms.\n"
        "Do not interpret storyline frequencies as predictive probabilities.\n"
    )
    (out_dir / "storylines_not_probabilities_disclaimer.txt").write_text(disclaimer, encoding="utf-8")

    # Save run configuration for traceability
    try:
        import json as _json
        (out_dir / "run_config.json").write_text(_json.dumps(vars(args), indent=2), encoding="utf-8")
    except Exception:
        pass

    # --- Locate the daily classifications CSV ---
    # If --classifications is provided, accept either an absolute path or a filename relative to base_dir.
    if args.classifications:
        cand = Path(args.classifications)
        class_path = cand if cand.is_absolute() else (base_dir / cand)
    else:
        # Look for the usual naming pattern anywhere under base_dir (handles subfolders).
        cands = sorted(base_dir.rglob("classifications_30regimes*.csv"))
        if not cands:
            csvs = sorted(base_dir.rglob("*.csv"))
            preview = ", ".join([p.name for p in csvs[:10]]) + (" ..." if len(csvs) > 10 else "")
            raise FileNotFoundError(
                f"No file matching classifications_30regimes*.csv was found under base_dir={base_dir}. "
                "Either move/rename your classifications file so it starts with 'classifications_30regimes', "
                "or pass --classifications with the full path. "
                f"CSV files seen (first 10): {preview}"
            )
        class_path = cands[0]

    if not class_path.exists():
        raise FileNotFoundError(f"Classifications file not found: {class_path}. Check the path/filename and OneDrive sync.")
    class_path = class_path.resolve()

    # Robust reader: Met Office "Decider" CSVs commonly begin with several comment lines
    # that start with '#', e.g. '# Met Office Decider'. If pandas reads that first line as
    # the header, you'll see columns like ['# Met Office Decider', 'Unnamed: 1', ...] and
    # the required date columns won't exist.
    #
    # Using comment="#" makes pandas ignore those comment lines so the real header line
    # (typically: day,month,year,regime,...) is parsed correctly.
    df = None
    last_err = None
    for kwargs in (
        {"comment": "#", "engine": "python"},  # most tolerant
        {"comment": "#"},
        {},  # last resort
    ):
        try:
            df = pd.read_csv(class_path, **kwargs)
            break
        except Exception as e:
            last_err = e

    if df is None:
        raise RuntimeError(f"Failed to read classifications CSV: {class_path}") from last_err

    # If the header still looks like a comment header, retry by scanning for the first
    # plausible header row that contains day/month/year.
    header_looks_wrong = any(str(c).startswith("#") for c in df.columns) or any(
        str(c).strip().lower().startswith("unnamed") for c in df.columns
    )
    if header_looks_wrong or (not any(str(c).strip().lower() == "year" for c in df.columns)):
        header_idx = None
        with open(class_path, "r", encoding="utf-8", errors="replace") as f:
            for i, line in enumerate(f):
                low = line.strip().lower().replace(" ", "")
                # accept either order, but require the three tokens to be present
                if "day" in low and "month" in low and "year" in low and "," in line:
                    header_idx = i
                    break
                if i > 500:
                    break
        if header_idx is not None:
            df = pd.read_csv(class_path, skiprows=header_idx, header=0)

    colmap = {c.lower(): c for c in df.columns}
    for req in ["year", "month", "day"]:
        if req not in colmap:
            raise ValueError(f"Missing required column '{req}' in {class_path.name}. Columns found: {list(df.columns)}")

    regime_col = None
    for cand in ["regime", "pattern", "wp", "weather_pattern", "class"]:
        if cand in colmap:
            regime_col = colmap[cand]
            break
    if regime_col is None:
        non_date = [c for c in df.columns if c not in [colmap["year"], colmap["month"], colmap["day"]]]
        if not non_date:
            raise ValueError("Could not find regime column.")
        regime_col = non_date[0]

    df["year"] = df[colmap["year"]].astype(int)
    df["month"] = df[colmap["month"]].astype(int)
    df["day"] = df[colmap["day"]].astype(int)
    df["date"] = pd.to_datetime(df[[colmap["year"], colmap["month"], colmap["day"]]], errors="coerce")

    df["regime"] = df[regime_col].astype(int)
    df["group"] = df["regime"].map(REGIME_TO_GROUP_4)
    if df["group"].isna().any():
        bad = df.loc[df["group"].isna(), "regime"].value_counts().head(10)
        raise ValueError(f"Some regimes could not be mapped. Examples:\n{bad}")

    df = df[df["year"].between(args.start_year, args.end_year) & df["month"].isin(months)].copy()
    df = df.sort_values("date")

    df["date_diff"] = df["date"].diff().dt.days
    breaks = (df["date_diff"].fillna(1) != 1).to_numpy()[1:]

    g2i = {g: i for i, g in enumerate(GROUP_ORDER)}
    df["state"] = df["group"].map(g2i).astype(int)

    states = df["state"].to_numpy()
    n_states = len(GROUP_ORDER)

    counts_overall, P_overall = fit_transition_matrix(states, n_states, breaks=breaks)

    P_monthly = None
    if use_monthly:
        P_monthly = {}
        for m in months:
            d = df[df["month"] == m].copy().sort_values("date")
            st = d["state"].to_numpy()
            d["date_diff"] = d["date"].diff().dt.days
            br = (d["date_diff"].fillna(1) != 1).to_numpy()[1:]
            _, Pm = fit_transition_matrix(st, n_states, breaks=br)
            P_monthly[m] = Pm    # start distribution (day-1 state) for simulations
    # Default: match observed distribution in the first selected month (keeps Step 3 comparable to observations).
    # Optional: use stationary distribution of the overall or first-month matrix to avoid "initial drag",
    # especially for strongly-perturbed dry/wet storylines.
    if args.init_mode == "observed_start_month":
        start_month = months[0]
        start_dist = np.zeros(n_states)
        start_states = df[df["month"] == start_month]["state"].to_numpy()
        for s in range(n_states):
            start_dist[s] = np.mean(start_states == s) if len(start_states) else 1.0 / n_states
        start_dist = safe_renormalize_row(start_dist)
    elif args.init_mode == "stationary_first_month":
        if use_monthly and P_monthly is not None and months[0] in P_monthly:
            start_dist = stationary_dist(P_monthly[months[0]])
        else:
            start_dist = stationary_dist(P_overall)
    else:  # stationary_overall
        start_dist = stationary_dist(P_overall)

    pd.DataFrame(P_overall, index=GROUP_ORDER, columns=GROUP_ORDER).to_csv(out_dir / "baseline_transition_probs_overall.csv")
    if P_monthly is not None:
        for m in months:
            pd.DataFrame(P_monthly[m], index=GROUP_ORDER, columns=GROUP_ORDER).to_csv(out_dir / f"baseline_transition_probs_month_{m:02d}.csv")

    runs_obs = compute_run_lengths(states)
    run_obs_df = summarize_runs(runs_obs, n_states)
    run_obs_df["group"] = run_obs_df["state"].map({i: g for g, i in g2i.items()})
    run_obs_df.to_csv(out_dir / "observed_run_length_summary.csv", index=False)

    obs_switch = switching_rate(states)

    # --- Optional rainfall attachment (for flip timing + anchor-year plausibility overlays) ---
    attach_rainfall = bool(args.attach_rainfall) and (not bool(args.no_attach_rainfall))
    rain_pools = None
    rain_all = None
    rain_df = None
    heavy_rain_thresh = None

    if attach_rainfall:
        try:

            rain_dir = Path(args.rain_dir)

            # Helpful debug (shows what argparse actually received).
            # If you think you passed --rain-daily but still see auto-discovery warnings,
            # open <output>/run_config.json; it records the parsed args.
            print(f"[INFO] Rainfall attach enabled. Parsed args: rain_daily='{args.rain_daily}', rain_dir='{rain_dir}'")

            # Prefer an explicit daily rainfall file if provided.
            rain_path = Path(args.rain_daily) if args.rain_daily else None

            # If not provided, attempt best-effort discovery under --rain-dir.
            if rain_path is None or str(rain_path).strip() == "":
                rain_path = discover_daily_rainfall_file(rain_dir)

            # Fallback: if discovery failed, but the user supplied --rain-summary-xlsx and it exists,
            # treat it as the daily rainfall input.
            if rain_path is None:
                sx = Path(args.rain_summary_xlsx) if args.rain_summary_xlsx else None
                if sx is not None and sx.exists():
                    rain_path = sx
                    print(f"[INFO] Using --rain-summary-xlsx as the daily rainfall file: {sx}")

            if rain_path is None:
                print(
                    f"[WARN] attach_rainfall=True but no daily rainfall file was found "
                    f"(no --rain-daily provided, and auto-discovery under --rain-dir failed). "
                    f"rain_dir={rain_dir}. Continuing without rainfall."
                )
            else:
                # If the user passed a relative path, interpret it as relative to --rain-dir.
                rain_path = rain_path if rain_path.is_absolute() else (rain_dir / rain_path)
                if not rain_path.exists():
                    raise FileNotFoundError(
                        f"Daily rainfall file does not exist: {rain_path}. "
                        f"(Parsed args: rain_daily='{args.rain_daily}', rain_dir='{rain_dir}')"
                    )

                rain_df = load_daily_rainfall(rain_path)
                rain_pools, rain_all = build_rain_pools_by_state_month(df[["date", "year", "month", "state"]], rain_df, months, n_states)

                if rain_all is not None and rain_all.size:
                    heavy_rain_thresh = float(np.quantile(rain_all, args.heavy_rain_q))

                # copy summary stats workbook to outputs (traceability)
                try:
                    sx = Path(args.rain_summary_xlsx)
                    if sx.exists():
                        import shutil
                        shutil.copy2(sx, out_dir / f"rain_summary_stats_{sx.name}")
                except Exception:
                    pass

                with open(out_dir / "rainfall_attachment_note.txt", "w", encoding="utf-8") as f:
                    f.write("Rainfall attachment (optional Step-3+ diagnostic)\n")
                    f.write("------------------------------------------------\n")
                    f.write(f"Daily rainfall file used: {str(rain_path)}\n")
                    f.write(f"Heavy-rain threshold quantile: q={args.heavy_rain_q}; threshold={heavy_rain_thresh}\n")
                    f.write(f"Number of (state,month) pools populated: {len(rain_pools)}\n")
        except Exception as e:
            print(f"[WARN] Failed to attach rainfall due to: {e}. Continuing without rainfall.")
            rain_pools = None
            rain_df = None
            heavy_rain_thresh = None

    story_mats = make_storyline_matrices(
        baseline_overall=P_overall,
        baseline_monthly=P_monthly,
        use_monthly=use_monthly,
        months=months,
        delta_persist=args.delta_persist,
        delta_burst=args.delta_burst,
        delta_return=args.delta_return,
        delta_dry_entry=args.delta_dry_entry,
    )

    rng = np.random.default_rng(args.seed)
    season_len = len(season_month_day_list(months))

    metrics_rows = []
    def add_metrics(storyline_code: str, sims: np.ndarray):
        """Compute ensemble metrics and append a row (code + label).

        This function writes BOTH:
        - traditional Markov diagnostics (composition, switching, max run lengths)
        - outbreak-sensitive metrics (Convective run counts and Settled↔Convective transitions)
        - flip-direction diagnostic (early-season wetness minus late-season wetness)

        Rainfall early/late diagnostics will be added in Step 4/5 once rainfall is attached
        to the simulated seasons (i.e., after driver sampling).
        """
        met = ensemble_metrics(sims, n_states)
        wb = ensemble_wet_balance_halves(sims, WET_STATE_IDX, split=args.flip_day)

        row = {
            "storyline_code": storyline_code,
            "storyline_label": STORYLINE_LABELS.get(storyline_code, storyline_code),
        }

        # --- Composition + max-run diagnostics per state ---
        for s in range(n_states):
            row[f"days_mean_{s}"] = met["days_mean"][s]
            row[f"days_p05_{s}"] = met["days_p05"][s]
            row[f"days_p95_{s}"] = met["days_p95"][s]
            row[f"maxrun_mean_{s}"] = met["maxrun_mean"][s]
            row[f"maxrun_p95_{s}"] = met["maxrun_p95"][s]

        # --- Switching ---
        row["switch_mean"] = met["switch_mean"]
        row["switch_p05"] = met["switch_p05"]
        row["switch_p95"] = met["switch_p95"]

        # --- Outbreak-sensitive convective diagnostics ---
        row["n_runs_conv_mean"] = met["n_runs_conv_mean"]
        row["n_runs_conv_p05"] = met["n_runs_conv_p05"]
        row["n_runs_conv_p95"] = met["n_runs_conv_p95"]

        row["mean_runlen_conv_mean"] = met["mean_runlen_conv_mean"]
        row["mean_runlen_conv_p05"] = met["mean_runlen_conv_p05"]
        row["mean_runlen_conv_p95"] = met["mean_runlen_conv_p95"]

        row["n_set_to_conv_mean"] = met["n_set_to_conv_mean"]
        row["n_set_to_conv_p05"] = met["n_set_to_conv_p05"]
        row["n_set_to_conv_p95"] = met["n_set_to_conv_p95"]

        row["n_conv_to_set_mean"] = met["n_conv_to_set_mean"]
        row["n_conv_to_set_p05"] = met["n_conv_to_set_p05"]
        row["n_conv_to_set_p95"] = met["n_conv_to_set_p95"]

        row["n_setconv_total_mean"] = met["n_setconv_total_mean"]
        row["n_setconv_total_p05"] = met["n_setconv_total_p05"]
        row["n_setconv_total_p95"] = met["n_setconv_total_p95"]

        # --- Flip-direction diagnostic (order-sensitive) ---
        for k, v in wb.items():
            row[k] = v

                # --- Optional rainfall timing diagnostics (Step 3+)
        # If rainfall pools are available, we attach rainfall i.i.d. conditional on (family, month),
        # then compute early vs late rainfall means and heavy-rain counts. This strengthens the flip-timing evidence.
        if rain_pools is not None:
            fallback_month = {}
            fallback_all = rain_all if (rain_all is not None and rain_all.size) else None
            if rain_df is not None:
                merged = df[["date", "month", "state"]].merge(rain_df, on="date", how="left")
                for mo in months:
                    arr = merged.loc[merged["month"] == mo, "rain_mm"].to_numpy()
                    arr = arr[np.isfinite(arr)]
                    fallback_month[int(mo)] = arr

            rain_sims = sample_rainfall_for_sims(
                sims=sims,
                month_seq=season_month_day_list(months),
                pools=rain_pools,
                rng=rng,
                fallback_month=fallback_month,
                fallback_all=fallback_all,
            )

            split = int(max(1, min(args.flip_day, rain_sims.shape[1] - 1)))
            r1 = np.nanmean(rain_sims[:, :split], axis=1)
            r2 = np.nanmean(rain_sims[:, split:], axis=1)
            rb = r1 - r2

            def q(x, p):
                return float(np.nanpercentile(x, p))

            row["rain_mean_first_mean"] = float(np.nanmean(r1))
            row["rain_mean_first_p05"] = q(r1, 5)
            row["rain_mean_first_p95"] = q(r1, 95)

            row["rain_mean_second_mean"] = float(np.nanmean(r2))
            row["rain_mean_second_p05"] = q(r2, 5)
            row["rain_mean_second_p95"] = q(r2, 95)

            row["rain_balance_first_minus_second_mean"] = float(np.nanmean(rb))
            row["rain_balance_first_minus_second_p05"] = q(rb, 5)
            row["rain_balance_first_minus_second_p95"] = q(rb, 95)

            if heavy_rain_thresh is not None and np.isfinite(heavy_rain_thresh):
                h1 = np.nansum(rain_sims[:, :split] >= heavy_rain_thresh, axis=1)
                h2 = np.nansum(rain_sims[:, split:] >= heavy_rain_thresh, axis=1)
                ht = h1 + h2
                row["n_heavy_rain_first_mean"] = float(np.nanmean(h1))
                row["n_heavy_rain_second_mean"] = float(np.nanmean(h2))
                row["n_heavy_rain_total_mean"] = float(np.nanmean(ht))
        else:
            row["rain_mean_first_mean"] = np.nan
            row["rain_mean_first_p05"] = np.nan
            row["rain_mean_first_p95"] = np.nan
            row["rain_mean_second_mean"] = np.nan
            row["rain_mean_second_p05"] = np.nan
            row["rain_mean_second_p95"] = np.nan
            row["rain_balance_first_minus_second_mean"] = np.nan
            row["rain_balance_first_minus_second_p05"] = np.nan
            row["rain_balance_first_minus_second_p95"] = np.nan
            row["n_heavy_rain_first_mean"] = np.nan
            row["n_heavy_rain_second_mean"] = np.nan
            row["n_heavy_rain_total_mean"] = np.nan

        metrics_rows.append(row)



    sims_baseline = simulate_storyline_ensemble(
        P_overall=story_mats["baseline"][0],
        P_monthly=story_mats["baseline"][1],
        months=months,
        start_dist=start_dist,
        n_sims=args.n_sims,
        rng=rng,
    )
    add_metrics("baseline", sims_baseline)

    sims_wet = simulate_storyline_ensemble(
        P_overall=story_mats["persistent_wet"][0],
        P_monthly=story_mats["persistent_wet"][1],
        months=months,
        start_dist=start_dist,
        n_sims=args.n_sims,
        rng=rng,
    )
    add_metrics("persistent_wet", sims_wet)

    sims_set = simulate_storyline_ensemble(
        P_overall=story_mats["persistent_dry"][0],
        P_monthly=story_mats["persistent_dry"][1],
        months=months,
        start_dist=start_dist,
        n_sims=args.n_sims,
        rng=rng,
    )
    add_metrics("persistent_dry", sims_set)

    sims_b = simulate_storyline_ensemble(
        P_overall=story_mats["dry_with_bursts"][0],
        P_monthly=story_mats["dry_with_bursts"][1],
        months=months,
        start_dist=start_dist,
        n_sims=args.n_sims,
        rng=rng,
    )
    add_metrics("dry_with_bursts", sims_b)

    # Two-phase seasons (mid-season change-point)
    flip_mode = args.flip_mode
    # Backwards compatibility: if user passed --flip-direction, map it to a flip mode
    if args.flip_direction is not None:
        flip_mode = "wet_to_dry" if args.flip_direction == "wet_to_settled" else "dry_to_wet"

    # Components
    P_wet_overall, P_wet_monthly = story_mats["flip_component_wet"]
    P_dry_overall, P_dry_monthly = story_mats["flip_component_dry"]

    if flip_mode in ["both", "wet_to_dry"]:
        sims_flip_w2d = simulate_storyline_ensemble(
            P_overall=P_wet_overall,
            P_monthly=P_wet_monthly,
            months=months,
            start_dist=start_dist,
            n_sims=args.n_sims,
            rng=rng,
            flip=True,
            flip_day=args.flip_day,
            P_overall_late=P_dry_overall,
            P_monthly_late=P_dry_monthly,
        )
        add_metrics("flip_wet_to_dry", sims_flip_w2d)

    if flip_mode in ["both", "dry_to_wet"]:
        sims_flip_d2w = simulate_storyline_ensemble(
            P_overall=P_dry_overall,
            P_monthly=P_dry_monthly,
            months=months,
            start_dist=start_dist,
            n_sims=args.n_sims,
            rng=rng,
            flip=True,
            flip_day=args.flip_day,
            P_overall_late=P_wet_overall,
            P_monthly_late=P_wet_monthly,
        )
        add_metrics("flip_dry_to_wet", sims_flip_d2w)
    metrics_df = pd.DataFrame(metrics_rows)
    metrics_df.to_csv(out_dir / "storyline_ensemble_metrics.csv", index=False)


    # Save overall matrices for plotting
    mats_for_plot = {
        "baseline": P_overall,
        "persistent_wet": story_mats["persistent_wet"][0],
        "persistent_dry": story_mats["persistent_dry"][0],
        "dry_with_bursts": story_mats["dry_with_bursts"][0],
    }
    plot_storyline_matrices(
        story_mats=mats_for_plot,
        outpath=out_dir / "figure_storyline_transition_matrices_overall.png",
        title="Storyline transition matrices (overall) — baseline vs perturbations",
        labels=STORYLINE_LABELS,
        order=["baseline", "persistent_wet", "persistent_dry", "dry_with_bursts"],
    )

    # Explicit two-phase ("flip") matrices: shows early vs late behaviour
    plot_flip_transition_matrices(
        P_wet=P_wet_overall,
        P_dry=P_dry_overall,
        outpath=out_dir / "figure_storyline_transition_matrices_flips.png",
        group_order=GROUP_ORDER,
    )


    plot_storyline_diagnostics(
        metrics_df=metrics_df,
        outpath=out_dir / "figure_storyline_diagnostics.png",
        season_len=season_len,
        order=[c for c in STORYLINE_ORDER if c in set(metrics_df["storyline_code"])],
        labels=STORYLINE_LABELS,
    )

    # --- Mechanism-specific figures (recommended for paper/reviewer clarity) ---
    try:
        plot_mechanism_persistence(
            P_base=P_overall,
            P_wet=story_mats["persistent_wet"][0],
            P_dry=story_mats["persistent_dry"][0],
            metrics_df=metrics_df,
            outpath=out_dir / "figure_mechanism_persistence_runlengths.png",
            labels=STORYLINE_LABELS,
        )
        plot_mechanism_storm_outbreaks(
            metrics_df=metrics_df,
            outpath=out_dir / "figure_mechanism_storm_outbreaks.png",
            labels=STORYLINE_LABELS,
        )
        plot_mechanism_flip_timing(
            metrics_df=metrics_df,
            outpath=out_dir / "figure_mechanism_flip_timing.png",
            labels=STORYLINE_LABELS,
        )
    except Exception as e:
        print(f"[WARN] Failed to write mechanism-specific figures: {e}")

    # --- Anchor-year plausibility check ---
    # Using 2012 + 2023 (wettest) and 2018 + 2022 (driest/dirtiest) by default.
    try:
        anchor_years = [int(x.strip()) for x in args.anchor_years.split(",") if x.strip()]
        anchor_df = compute_anchor_year_metrics(
            df_states=df[["date", "year", "month", "state"]],
            months=months,
            years=anchor_years,
            wet_states=WET_STATE_IDX,
            split=args.flip_day,
            n_states=n_states,
            rain_df=rain_df if (rain_df is not None and rain_pools is not None) else None,
            heavy_rain_thresh=heavy_rain_thresh,
        )
        anchor_df.to_csv(out_dir / "anchor_year_metrics.csv", index=False)

        plot_anchor_year_plausibility(
            metrics_df=metrics_df,
            anchor_df=anchor_df,
            outpath=out_dir / "figure_anchor_year_plausibility.png",
            story_order=[c for c in STORYLINE_ORDER if c in set(metrics_df["storyline_code"])],
            labels=STORYLINE_LABELS,
        )
    except Exception as e:
        print(f"[WARN] Anchor-year plausibility check failed: {e}")

    with open(out_dir / "storyline_summary.txt", "w", encoding="utf-8") as f:
        f.write("Step 3: Arnell-style storylines (Markov perturbations)\n")
        f.write("-----------------------------------------------------\n")
        f.write(f"Period: {args.start_year}-{args.end_year}; Months: {months}\n")
        f.write(f"Use monthly matrices: {use_monthly}\n")
        f.write(f"N simulations per storyline: {args.n_sims}; Seed: {args.seed}\n\n")
        f.write(f"Observed switching rate (concatenated observed sequence): {obs_switch:.3f}\n")
        f.write("Baseline P_overall diagonal (persistence):\n")
        for i, g in enumerate(GROUP_ORDER):
            f.write(f"  {g}: {P_overall[i, i]:.2f}\n")
        f.write("\nPerturbation parameters:\n")
        f.write(f"  delta_persist={args.delta_persist}\n")
        f.write(f"  delta_burst={args.delta_burst}\n")
        f.write(f"  delta_return={args.delta_return}\n")
        f.write(f"  flip_day={args.flip_day}; flip_mode={flip_mode}\n")
        f.write("\nDiagnostics notes:\n")
        f.write("  Flip wetness definition: Cyclonic + Showery + Convective (all non-Settled).\n")
        f.write("  Outbreak metrics: Convective run counts + Settled↔Convective transitions.\n")
        f.write("  Storylines are stress tests (plausible) and are NOT probabilistic forecasts.\n")
        if rain_pools is not None:
            f.write(f"  Rainfall attached (optional Step-3+): heavy-rain threshold={heavy_rain_thresh} (q={args.heavy_rain_q}).\n")
        else:
            f.write("  Rainfall attached (optional Step-3+): NO (not found or disabled).\n")
        f.write(f"  Anchor-year plausibility check years: {args.anchor_years}\n")


    print(f"Done. Outputs written to: {out_dir}")

if __name__ == "__main__":
    main()
